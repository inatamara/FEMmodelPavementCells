function cellarray = PressureA(cellarray,PxL,PxR,nnel)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
        Pressure = zeros(nnel*3,1);
        Pressure([1,10,13,22],1) = PxL;
        Pressure([4,7,16,19],1) = PxR;
        cellarray = Pressure;
end

