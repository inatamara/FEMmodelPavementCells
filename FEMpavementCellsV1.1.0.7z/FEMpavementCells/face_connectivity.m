function faces = face_connectivity(nodes)
%**********************************************************************%
%----------------------------------------------------------------------%
%| This function creates the internal_element face connectivity |%
%| |%
%| |%
%| |%
%| |%
%----------------------------------------------------------------------%
%**********************************************************************%
%
% Synopsis: faces = face_connectivity(nodes)
%
% Input: node > Natural node ordering for elements

faces = zeros(1,4);
face = zeros(6,4);
face1 = [1 2 6 5];
face2 = [2 3 7 6];
face3 = [3 4 8 7];
face4 = [4 1 5 8];
face5 = [1 2 3 4];
face6 = [5 6 7 8];
% face1 = [1 2 5 6];
% face2 = [2 3 6 7];
% face3 = [3 4 8 7];
% face4 = [4 1 5 8];
% face5 = [1 2 3 4];
% face6 = [5 6 7 8];
% face1 = [1 2 3 4];
% face2 = [4 3 7 8];
% face3 = [5 6 7 8];
% face4 = [2 6 7 3];
% face5 = [1 5 8 4];
% face6 = [1 2 6 5];

for i = 1:size(nodes,1)
face = [nodes(i,face1);nodes(i,face2);nodes(i,face3);nodes(i,face4);nodes(i,face5);nodes(i,face6)];
faces = cat(1,faces,face);
end
faces(1,:) = [];
faces = faces;
% end