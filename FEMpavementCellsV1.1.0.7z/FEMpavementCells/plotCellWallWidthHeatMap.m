% run main function first: mainFunction_FEMpavementCells
% this scripts allows to vizualize the heatmaps of the cell wall thickness
% as shown in figure 3D and to plot cell wall segments as shown in the
% figure 3C.
%%
% get the incompatible growth mesh at the growth stage ind
for IE=1:data.nel% number of elements
CorInc(:,:,IE) = XYZ(LE(IE,:),:);
end
for ind = 1:numel(XYZT)
    CorInc = CorInc + permute(dispFgINC{ind},[2,1,3]);
    inCompatibleXYZT{ind} = CorInc; % incompatible grown position at growth iteration ind
end
%%
clear cormatL cormatR cormatM

cmap = jet(numel(XYZT));
for ind = 1:200%numel(XYZT) % loop owar the growth iterations

tot = 1;
if tot == 1 % growth with pressure
    cormat = XYZT{ind};%Cor;%{1};
elseif tot == 2 % incopatible growth
    cormat = inCompatibleXYZT{ind}; % incompatible growth
else
    cormat = XYZTcompatiblme{ind}; % compatible growth without pressure
end
hlev = 3;
nelAl = nelPb+hlev*Ny*3+1:3:nelPb+Ny*3+hlev*Ny*3;
nelAm = nelPb+hlev*Ny*3+2:3:nelPb+Ny*3+hlev*Ny*3;
nelAr = nelPb+hlev*Ny*3+3:3:nelPb+Ny*3+hlev*Ny*3;
%
nAl = numel(nelAl);
L_yl(ind,:) = [0,0];
L_yr(ind,:) = [0,0];
cormatL{ind}= zeros(8,3,nAl); % compatible element displacements due to growth
cormatR{ind}= zeros(8,3,nAl); % compatible element displacements due to growth
cormatM{ind}= zeros(8,3,nAl); % compatible element displacements due to growth
for IE=1:nAl% number of elements  
    if tot == 1
    cormatL{ind}(:,:,IE) = cormat(LE(nelAl(IE),:),:); 
    L_yl(ind,:) = L_yl(ind,:) + [eldist(cormatL{ind}(:,:,IE),1,4),eldist(cormatL{ind}(:,:,IE),2,3)];
    L_lwx(IE,1) = sum([eldist(cormatL{ind}(:,:,IE),1,2),eldist(cormatL{ind}(:,:,IE),4,3)])/2;
    
    cormatR{ind}(:,:,IE) = cormat(LE(nelAr(IE),:),:); 
    L_yr(ind,:) = L_yr(ind,:) + [eldist(cormatR{ind}(:,:,IE),1,4),eldist(cormatR{ind}(:,:,IE),2,3)];
    L_rwx(IE,1) = sum([eldist(cormatR{ind}(:,:,IE),1,2),eldist(cormatR{ind}(:,:,IE),4,3)])/2;
    
    cormatM{ind}(:,:,IE) = cormat(LE(nelAm(IE),:),:); 
    L_mwx(IE,1) = sum([eldist(cormatM{ind}(:,:,IE),1,2),eldist(cormatM{ind}(:,:,IE),4,3)])/2;
    else
    cormatL{ind}(:,:,IE) = cormat(:,:,nelAl(IE)); 
    L_yl(ind,:) = L_yl(ind,:) + [eldist(cormatL{ind}(:,:,IE),1,4),eldist(cormatL{ind}(:,:,IE),2,3)];
    L_lwx(IE,1) = sum([eldist(cormatL{ind}(:,:,IE),1,2),eldist(cormatL{ind}(:,:,IE),4,3)])/2;
    
    cormatR{ind}(:,:,IE) = cormat(:,:,nelAr(IE)); 
    L_yr(ind,:) = L_yr(ind,:) + [eldist(cormatR{ind}(:,:,IE),1,4),eldist(cormatR{ind}(:,:,IE),2,3)];
    L_rwx(IE,1) = sum([eldist(cormatR{ind}(:,:,IE),1,2),eldist(cormatR{ind}(:,:,IE),4,3)])/2;
    
    cormatM{ind}(:,:,IE) = cormat(:,:,nelAm(IE)); 
    L_mwx(IE,1) = sum([eldist(cormatM{ind}(:,:,IE),1,2),eldist(cormatM{ind}(:,:,IE),4,3)])/2;
    end
end
WidthY(:,ind) = sum([L_lwx,L_rwx,L_mwx],2);
% plot(WidthY(:,ind),'Color',cmap(ind,:),'LineWidth',lw)
end
% figure properties
width = 2;% Width in inches
height = 2; %height in inches
alw=1.5;% AxesLineWidth
fsz=10; % Fontsize
lw=3;%  % LineWidth
msz=15; % MarkerSize
fszl=8; % Fontsize legend
fontname='Helvetica'; % Fontsize name
tickdir = 'out';
ticksize= [0.02 0.035]; % Fontsize legend
f1 = figure;
imagesc(WidthY(2:end-1,:)');colormap(cmap)
xl = xlabel('Anticlinal wall element Y id');
set(xl,'FontName',fontname,'FontSize',fsz)
yl = ylabel('Iteration');

h = colorbar;
cl = ylabel(h, 'Cell wall thickness (nm)');
caxis([35,170])
set(yl,'FontName',fontname,'FontSize',fsz)
set(gca,'TickDir', tickdir);
set(gca,'TickLength', ticksize); 
set(gca, 'FontSize', fsz, 'LineWidth', alw); 
set(gca,'box','off');
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1)-100 pos(2)-100 width*80, height*80]); %<- Set size
set(gcf,'color','w')
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
%%
This part visualize the anticlinl wall segments as shown in the figure 3C
width = 5;% Width in inches
height = 5; %height in inches
pl = 1;
if pl
    ind = 200; % select the growth iteration to display the anaticlinal wall segment
fh = figure ;
axis equal ;
hold on
unitfac = 1;
coll = [115 76 104]/255;
colm = [27 64 79]/255;
colr = [138 138 191]/255;
% nAl, number of elements in the left anticlinal wall layers
    for IE=2:nAl-1% select the  number of elements to plot, here the middle 
%         segment along the anticlinal wall; three element thick and 1 element high
    set(fh,'name',sprintf('Iteration #: %d',ind),'numbertitle','off','color','w') ;
    patch('Vertices', cormatL{ind}(:,:,IE),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',coll)      
    
     set(fh,'numbertitle','off','color','w') ;
    patch('Vertices', cormatM{ind}(:,:,IE),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',colm)    

    set(fh,'numbertitle','off','color','w') ;
    patch('Vertices', cormatR{ind}(:,:,IE),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',colr)  
    end
        view([15,45])
%         axis([-500 1000 -1000 2000]) %iter281 WT
      axis([-500 1200 -1200 2500]) %iter250 WT
        set(gca,'visible','off')
        tl = title(sprintf('Iteration #: %d',ind));
        set(tl,'FontName',fontname,'FontSize',fsz)
        pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1)-100 pos(2)-100 width*80, height*80]); %<- Set size
set(gcf,'color','w')
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
end