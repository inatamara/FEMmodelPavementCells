function prof = EXOprofile(mini,max_high,max_low,Ny,gauss)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

if isempty(gauss)
%     x = 0:pi/(Ny/2-1):pi;
    x = linspace(0,pi,Ny/2);
    y = sin(x);
    ymax = nma_rescale(y,mini,max_high)';
    yd2 = fliplr(y);
    ymin = nma_rescale(yd2,mini,max_low)';
    prof = [ymax(:);ymin(:)];
else
    x = 1:Ny+1;
    xm = Ny/2 + 1;
    A1 = 1;
    sig = gauss(1);
    y= A1*exp(-(((x-xm)/sig).^2)/2);%/sig/(2*pi);%/(2*(2*2));
    yd = diff(y);
    yd1 = yd(1:numel(yd)/2);
    ymax = nma_rescale(yd1,mini,max_high)';
% ymax = ymax(1:end);
ymin = fliplr(nma_rescale(yd1,mini,max_low))';
% ymin = ymin(2:end);
prof = [ymax(:);ymin(:)];
prof = nma_rescale(prof,mini,max_high)';
end

end

