function [dshapedx,dshapedy,dshapedz]=...
ShapefunctionDerivatives3D(nnel,dshapedxi,dshapedeta,dshapedksi,invjacob)

%------------------------------------------------------------------------
%  Purpose:
%     determine derivatives of  isoparametric 8 node hexaedral shape functions with 
%     respect to physical coordinate system
%
%  Synopsis:
%     [dshapedx,dshapedy]=shapefunctionderivatives(nnel,dshapedxi,dshapedeta,invjacob)  
%
%  Variable Description:
%     dshapedx - derivative of shape function w.r.t. physical coordinate x
%     dshapedy - derivative of shape function w.r.t. physical coordinate y
%     nnel - number of nodes per element   
%     dshapedxi - derivative of shape functions w.r.t. natural coordinate xi
%     dshapedeta - derivative of shape functions w.r.t. natural coordinate eta
%     invjacob - inverse of  Jacobian matrix
%------------------------------------------------------------------------

 for i=1:nnel
 dshapedx(i)=invjacob(1,1)*dshapedxi(i)+invjacob(1,2)*dshapedeta(i)+invjacob(1,3)*dshapedksi(i);
 dshapedy(i)=invjacob(2,1)*dshapedxi(i)+invjacob(2,2)*dshapedeta(i)+invjacob(2,3)*dshapedksi(i);
 dshapedz(i)=invjacob(3,1)*dshapedxi(i)+invjacob(3,2)*dshapedeta(i)+invjacob(3,3)*dshapedksi(i);
 end
