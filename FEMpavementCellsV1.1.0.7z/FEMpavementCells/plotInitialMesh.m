% this script plots the initial mesh (load first MEshData.mat)

% LE - nodes conectivity matrix of a mesh
% Cor - coordinates of a mesh
faces = face_connectivity(LE);   
%   Plotting the Finite Element Mesh
fh = figure;
set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
patch('Vertices',Cor,'Faces',faces,...
'FaceVertexCData',hsv(1),'FaceColor','none')
title('Finite Element Mesh of T') ;
% axis([0. L*1.01+orWx 0. B*1.01 0. H*1.01+4*orWz])
% axis off ;
if L==B==H
    axis equal;
end