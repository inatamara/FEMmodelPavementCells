function cellarray = PressurePt(Py,nnel,par)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
        Pressure = zeros(nnel*3,1);
        Pressure([3,6,9,12],1) = Py;
        
        if par
            Pressure([15,18,21,24],1) = par;
        end
        cellarray = Pressure;
end

