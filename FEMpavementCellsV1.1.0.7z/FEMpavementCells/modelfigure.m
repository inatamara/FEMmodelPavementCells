%% loada a mesh data first
cols = unique(ELidentity);
cmap = jet(numel(cols));
ELidCmap = 0;
faces = face_connectivity(LE); 
iter0 = 1:nel;%nelPb+1:nelA+nelPb+nelPt;%+nelA+1:nelPb+nelA+1*nelPt;
%IE= 1:nelPb+nelA+1%+2*nelPt:nelPb+nelA+3*nelPt%1:nel %number of elements 
cormat = Cor;%T{ind};%Cor;%{1};
fh = figure ;
axis equal ;
hold on
 patch('Vertices',cormat,'Faces',faces,...
    'FaceVertexCData',hsv(1),'FaceColor','none')
for IE = iter0
if ELidentity(IE) == 100 | ELidentity(IE) == sqrt(2) | ELidentity(IE) == 110 | ELidentity(IE) == -2 | ELidentity(IE) == -6 | ELidentity(IE) == -4 
set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','b')   
elseif ELidentity(IE) == 101 | ELidentity(IE) == sqrt(3) | ELidentity(IE) == 111| ELidentity(IE) == -3 | ELidentity(IE) == -7 | ELidentity(IE) == -5
set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','g') 
elseif ELidentity(IE) == 10 | ELidentity(IE) == 1 | ELidentity(IE) == 11| ELidentity(IE) ==-617
set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','m') 
else
    set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','w') 
end
end
 set(gca,'visible','off')
%%
figure
    set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
patch('Vertices', cormat(LE(1,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','none') 
