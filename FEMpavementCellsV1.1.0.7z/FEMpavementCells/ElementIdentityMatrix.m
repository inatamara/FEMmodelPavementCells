function [ELidentityPb,ELidentityA,ELidentityPt,ELidentityPt2,indJ,index] = ...
         ElementIdentityMatrix(data,Nx,NxT,Ny,Nz)
%nodalPresureHjuncML3 function creates element identity matrix used later to identify 
% different elements and apply appriopriate growth law (i.e. anticlinal vs periclinal element etc.)  
%   Detailed explanation goes here
indELPt = data.nelPb + 1 + data.nelA:data.nelPb + data.nelA + data.nelPt;
indELPb = 1:data.nelPb;
indPtL = repmat(1:(NxT-1)/2-1,[Ny,1])+ NxT*[0:Ny-1]';
indPtL = indPtL(:);
% same for right elements, without junction nodes
indPtR = repmat((NxT-1)/2 + 3:NxT,[Ny,1])+ NxT*[0:Ny-1]';
indPtR  =indPtR(:);
% middle row of periclinal walls
indJ = repmat(Nx/2 + 1,[Ny,1])+ NxT*[0:Ny-1]';
% left to the middle row
% indL = repmat([(NxT-1)/2-1:(NxT-1)/2],[Ny,1])+ NxT*[0:Ny-1]';
indL = repmat(Nx/2,[Ny,1])+ NxT*[0:Ny-1]';
% right to the middle peric raw
indR = repmat(Nx/2 + 2,[Ny,1])+ NxT*[0:Ny-1]';
index.indL = indL;
index.indR = indR;
index.indJ = indJ;
% indR = repmat([(NxT-1)/2 + 2:(NxT-1)/2 + 2+1],[Ny,1])+ NxT*[0:Ny-1]';
% x boundary condition elements
indXPt = [1:NxT:NxT*Ny-Nx,NxT:NxT:NxT*Ny];
indXPtL = 1:NxT:NxT*Ny-Nx;
indXPtR = NxT:NxT:NxT*Ny;
% y boundary condition elements
indYPt = [1:NxT,NxT*Ny-Nx:NxT*Ny];
indYPtLB = 2:Nx/2;
indYPtLT = NxT*Ny-Nx+1:NxT*Ny-Nx/2-1;
indYPtRB = Nx/2 + 2:NxT-1;
indYPtRT = NxT*Ny-Nx/2:NxT*Ny-1;

% elements with x and y boundary
indXYPt = intersect(indYPt,indXPt);
index.indXYPt = indELPt(indXYPt);
indXYPtLB = indXYPt(1);
indXYPtLT = indXYPt(3);
indXYPtRB = indXYPt(2);
indXYPtRT = indXYPt(4);

index.indXYPtLB = indELPt(indXYPtLB);
index.indXYPtRB = indELPt(indXYPtRB);
index.indXYPtLT = indELPt(indXYPtLT);
index.indXYPtRT = indELPt(indXYPtRT);

indPt10 = Nx/2+1;
indPt11 = NxT*Ny-Nx/2;
indPt100 = Nx/2;
indPt110 = NxT*Ny-Nx/2-1;
indPt101 = Nx/2+2;
indPt111 = NxT*Ny-Nx/2+1;

index.indPt100 = indELPt(indPt100);
index.indPt110 = indELPt(indPt110);
index.indPt101 = indELPt(indPt101);
index.indPt111 = indELPt(indPt111);
index.indPt10 = indELPt(indPt10);
index.indPt11 = indELPt(indPt11);
index.indPtL = indELPt(indPtL);
index.indPtR = indELPt(indPtR);
index.indPtLadjA = indELPt(indL);
index.indPtRadjA = indELPt(indR);
index.indXPtBC = indELPt(indXPt);
index.indXPtBCL = indELPt(indXPtL);
index.indXPtBCR = indELPt(indXPtR);
index.indYPtBCLT = indELPt(indYPtLT);
index.indYPtBCRB = indELPt(indYPtRB);
index.indYPtBCLB = indELPt(indYPtLB);
index.indYPtBCRT = indELPt(indYPtRT);
index.indPtJA = indELPt(indJ);
% element identity pezriclinal top
ELidentityPt = zeros(data.nelPt,1);
ELidentityPt(indPtL) = 2; % not in conntact with any anticlinal wall element 
% and not a border element, first layer of top periclinal wall Left side
ELidentityPt(indPtR) = 3; % not in conntact with any anticlinal wall element 
% and not a border element, first layer of top periclinal wall Right side
ELidentityPt(indL) = -2; % in conntact with last strip of anticlinal wall Left elements, first layer, does not include Y border elements
ELidentityPt(indR) = -3; % in conntact with last strip of anticlinal wall Right elements, first layer, does not include Y border elements
ELidentityPt(indXPtL) = 20; % Y boundary elements in first layer of periclinal wall, Left side
ELidentityPt(indXPtR) = 30;  % Y boundary elements in first layer of periclinal wall, Right side
ELidentityPt(indYPtLT) = 200; % X boundary elements in first layer of periclinal wall, top left side
ELidentityPt(indYPtRT) = 300;% X boundary elements in first layer of periclinal wall, Top Right side
ELidentityPt(indYPtLB) = 2000; % X boundary elements in first layer of periclinal wall, Left bottom side
ELidentityPt(indYPtRB) = 3000;% X boundary elements in first layer of periclinal wall, Right bottom side
ELidentityPt(indXYPtLB) = -20; % X boundary single corner element in first layer of periclinal wall, Left bottom side
ELidentityPt(indXYPtRB) = -30; % X boundary single corner element in first layer of periclinal wall, Right bottom side
ELidentityPt(indXYPtLT) = -200; % X boundary single corner element in first layer of periclinal wall, Left top side
ELidentityPt(indXYPtRT) = -300; % X boundary single corner element in first layer of periclinal wall, Right top side
ELidentityPt(indJ) = -213;% middle row of top 1 layer periclinal directly in conntact with anticlinal (above)

ELidentityPt(intersect(indPt10,indJ)) = 10;% middle edge of anticlinal wall 
% elements in bottom (facing negative Y) including periclinal elements
ELidentityPt(intersect(indPt11,indJ)) = 11;% middle edge of anticlinal wall 
% elements in top (facing positive Y) including periclinal elements
ELidentityPt(intersect(indPt100,indL)) = 100;% Left edge of anticlinal wall 
% elements in bottom (facing negative Y) including periclinal elements
ELidentityPt(intersect(indPt110,indL)) = 110;% middle edge of anticlinal wall 
% elements in top (facing positive Y) including periclinal elements
ELidentityPt(intersect(indPt101,indR)) = 101;% Right edge of anticlinal wall 
% elements in bottom (facing negative Y) including periclinal elements
ELidentityPt(intersect(indPt111,indR)) = 111;% Right edge of anticlinal wall 
% elements in top (facing positive Y) including periclinal elements
%% third peric top
indELPt2 = data.nelPb + 1 + data.nelA + data.nelPt:data.nelPb + data.nelA + 2*data.nelPt;

index.indXYPt2LB = indELPt2(indXYPtLB);
index.indXYPt2RB = indELPt2(indXYPtRB);
index.indXYPt2LT = indELPt2(indXYPtLT);
index.indXYPt2RT = indELPt2(indXYPtRT);

index.indPt2_100 = indELPt2(indPt100);
index.indPt2_110 = indELPt2(indPt110);
index.indPt2_101 = indELPt2(indPt101);
index.indPt2_111 = indELPt2(indPt111);

index.indPt2_10 = indELPt2(indPt10);
index.indPt2_11 = indELPt2(indPt11);
index.indPt2L = indELPt2(indPtL);
index.indPt2R = indELPt2(indPtR);
index.indPt2LadjA = indELPt2(indL);
index.indPt2RadjA = indELPt2(indR);
index.indXPt2BC = indELPt2(indXPt);
index.indXPt2BCL = indELPt2(indXPtL);
index.indXPt2BCR = indELPt2(indXPtR);
index.indYPt2BCLT = indELPt2(indYPtLT);
index.indYPt2BCRB = indELPt2(indYPtRB);
index.indYPt2BCLB = indELPt2(indYPtLB);
index.indYPt2BCRT = indELPt2(indYPtRT);
index.indPt2JA = indELPt2(indJ);
% element identity pezriclinal top
ELidentityPt2 = zeros(data.nelPt,1);
ELidentityPt2(indPtL) = 6;% not in conntact with any anticlinal wall element 
% and not a border element, second layer of top periclinal wall Left side
ELidentityPt2(indPtR) = 7; % not in conntact with any anticlinal wall element 
% and not a border element, second layer of top periclinal wall Right side
ELidentityPt2(indL) = -6; % on top of -2 elements
ELidentityPt2(indR) = -7; % on top of -3 elements
ELidentityPt2(indXPtL) = 60; % Y boundary elements in 2 layer of periclinal wall, Left side
ELidentityPt2(indXPtR) = 70; % Y boundary elements in 2 layer of periclinal wall, Right side
ELidentityPt2(indYPtLT) = 600;% X boundary elements in 2 layer of periclinal wall, top left side
ELidentityPt2(indYPtRT) = 700;% X boundary elements in 2 layer of periclinal wall, top right side
ELidentityPt2(indYPtLB) = 6000;% X boundary elements in 2 layer of periclinal wall, bottom left side
ELidentityPt2(indYPtRB) = 7000;% X boundary elements in 2 layer of periclinal wall, bottom right side
ELidentityPt2(indXYPtLB) = -60;% X boundary single corner element in 2 layer of periclinal wall, Left bottom side
ELidentityPt2(indXYPtRB) = -70;% X boundary single corner element in 2 layer of periclinal wall, Right bottom side
ELidentityPt2(indXYPtLT) = -600;% X boundary single corner element in 2 layer of periclinal wall, Left top side
ELidentityPt2(indXYPtRT) = -700;% X boundary single corner element in 2 layer of periclinal wall, Right top side
% ELidentityPt2(intersect(indL,) = -2000; % sharing halve of the nodes with anticlinal L
ELidentityPt2(indJ) = -617;% middle row of top 2 layer periclinal directly in conntact with anticlinal (above)
ELidentityPt2(intersect(indPt10,indJ)) = 10;% middle edge of anticlinal wall 
% elements in bottom (facing negative Y) including periclinal elements
ELidentityPt2(intersect(indPt11,indJ)) = 11;% middle edge of anticlinal wall 
% elements in top (facing positive Y) including periclinal elements
ELidentityPt2(intersect(indPt100,indL)) = 100;% Left edge of anticlinal wall 
% elements in bottom (facing negative Y) including periclinal elements
ELidentityPt2(intersect(indPt110,indL)) = 110;% middle edge of anticlinal wall 
% elements in top (facing positive Y) including periclinal elements
ELidentityPt2(intersect(indPt101,indR)) = 101;% Right edge of anticlinal wall 
% elements in bottom (facing negative Y) including periclinal elements
ELidentityPt2(intersect(indPt111,indR)) = 111;% Right edge of anticlinal wall 
% elements in top (facing positive Y) including periclinal elements
%% peric bottom
indPbL = repmat(1:Nx/2-1,[Ny,1])+ NxT*[0:Ny-1]';
indPbL = indPbL(:);
% same for right elements, without junction nodes
indPbR = repmat(Nx/2 + 3:NxT,[Ny,1])+ NxT*[0:Ny-1]';
indPbR = indPbR(:);

% x boundary condition elements
indXPb = [1:NxT:NxT*Ny-Nx,NxT:NxT:NxT*Ny];
indXPbL = 1:NxT:NxT*Ny-Nx;
indXPbR = NxT:NxT:NxT*Ny;
% y boundary condition elements
indYPb = [1:NxT,NxT*Ny-Nx:NxT*Ny];
indYPbLB = 2:Nx/2;
indYPbLT = NxT*Ny-Nx+1:NxT*Ny-Nx/2-1;
indYPbRB = Nx/2 + 2:NxT-1;
indYPbRT = NxT*Ny-Nx/2:NxT*Ny-1;

% elements with x and y boundary
indXYPb = intersect(indYPb,indXPb);
index.indXYPb = indELPb(indXYPb);
indXYPbLB = indXYPb(1);
indXYPbLT = indXYPb(3);
indXYPbRB = indXYPb(2);
indXYPbRT = indXYPb(4);

index.indXYPbLB = indELPb(indXYPbLB);
index.indXYPbRB = indELPb(indXYPbRB);
index.indXYPbLT = indELPb(indXYPbLT);
index.indXYPbRT = indELPb(indXYPbRT);

indPb10 = Nx/2+1;
indPb11 = NxT*Ny-Nx/2;
indPb100 = Nx/2;
indPb110 = NxT*Ny-Nx/2-1;
indPb101 = Nx/2+2;
indPb111 = NxT*Ny-Nx/2+1;

index.indPb10 = indELPb(indPb10);
index.indPb11 = indELPb(indPb11);
index.indPb100 = indELPb(indPb100);
index.indPb110 = indELPb(indPb110);
index.indPb101 = indELPb(indPb101);
index.indPb111 = indELPb(indPb111);

index.indPbL = indELPb(indPbL);
index.indPbR = indELPb(indPbR);
index.indPbLadjA = indELPb(indL);
index.indPbRadjA = indELPb(indR);
index.indXPbBC = indELPb(indXPb);
index.indXPbBCL = indELPb(indXPbL);
index.indXPbBCR = indELPb(indXPbR);
index.indYPbBCLT = indELPb(indYPbLT);
index.indYPbBCRB = indELPb(indYPbRB);
index.indYPbBCLB = indELPb(indYPbLB);
index.indYPbBCRT = indELPb(indYPbRT);
index.indPbJA = indELPb(indJ);
% element identity pezriclinal top
ELidentityPb = zeros(data.nelPb,1);
ELidentityPb(indPbL) = 4; % not in conntact with any anticlinal wall element 
% and not a border element, bottom periclinal wall Left side
ELidentityPb(indPbR) = 5; % not in conntact with any anticlinal wall element 
% and not a border element, bottom periclinal wall Right side
ELidentityPb(indL) = -4; % in conntact with last strip of anticlinal wall Left elements, does not include Y border elements
ELidentityPb(indR) = -5; % in conntact with last strip of anticlinal wall Right elements, first layer, does not include Y border elements
ELidentityPb(indXPbL) = 40;% Y boundary elements in bottom  periclinal wall, Left side
ELidentityPb(indXPbR) = 50;% Y boundary elements in bottom  periclinal wall, Right side
ELidentityPb(indYPbLT) = 400;% X boundary elements in bottom  periclinal wall, Top Left side
ELidentityPb(indYPbRT) = 500;% X boundary elements in bottom  periclinal wall, Top Right side
ELidentityPb(indYPbLB) = 4000; %X boundary elements in bottom  periclinal wall, bottom Left side
ELidentityPb(indYPbRB) = 5000;% X boundary elements in bottom  periclinal wall, bottoom periclinal wall, Left bottom corner
ELidentityPb(indXYPbRB) = -50;% X boundary elements in bottom  periclinal wall, bottoom periclinal wall, right bottom corner
ELidentityPb(indXYPbLT) = -400;% X boundary elements in bottom  periclinal wall, bottoom periclinal wall, Left top corner
ELidentityPb(indXYPbRT) = -500;% X boundary elements in bottom  periclinal wall, bottoom periclinal wall, Right top corner
ELidentityPb(indJ) = -415;% % middle row of bottom periclinal directly in conntact with anticlinal (below)
ELidentityPb(intersect(indPt10,indJ)) = 10; % as abowe
ELidentityPb(intersect(indPt11,indJ)) = 11;% as abowe
ELidentityPb(intersect(indPt100,indL)) = 100;% as abowe
ELidentityPb(intersect(indPt110,indL)) = 110;% as abowe
ELidentityPb(intersect(indPt101,indR)) = 101;% as abowe
ELidentityPb(intersect(indPt111,indR)) = 111;% as abowe
%%%%%%%%%%%%%%%%%%%%%%%%
% anticlinal left
indAL = 1:3:data.nelA;
% element identity
ELidentityA = zeros(data.nelA ,1); % anticlinal left, without y border elements
ELidentityA(indAL) = sqrt(2);

indAR = 3:3:data.nelA;
ELidentityA(indAR) = sqrt(3); % anticlinal right, without y border elements

indAM = 2:3:data.nelA;
ELidentityA(indAM) = 1; % anticlinal middle, without y border elements
%ELidentity = 10;% middle edge of anticlinal wall 
% elements in bottom (facing negative Y) including periclinal elements
%ELidentity = 11;% middle edge of anticlinal wall 
% elements in top (facing positive Y) including periclinal elements
%ELidentity = 100;% Left edge of anticlinal wall 
% elements in bottom (facing negative Y) including periclinal elements
%ELidentity = 110;% middle edge of anticlinal wall 
% elements in top (facing positive Y) including periclinal elements
%ELidentityPt2 = 101;% Right edge of anticlinal wall 
% elements in bottom (facing negative Y) including periclinal elements
%ELidentityPt2= 111;% Right edge of anticlinal wall 
% elements in top (facing positive Y) including periclinal elements
% now +y border elements
indYApL = [1:Nz]*Ny*3-2;
ELidentityA(indYApL) = 110;
indYApR = [1:Nz]*Ny*3;
ELidentityA(indYApR) = 111;
indYApM = [1:Nz]*Ny*3-1;
ELidentityA(indYApM) = 11;
% now -y border elements
indYAmL = [0:Nz-1]*Ny*3+1;
ELidentityA(indYAmL) = 100;
indYAmR = [0:Nz-1]*Ny*3+3;
ELidentityA(indYAmR) = 101;
indYAmM = [0:Nz-1]*Ny*3+2;
ELidentityA(indYAmM) = 10;

indELA = data.nelPb + 1:data.nelPb + data.nelA;
index.indAL = indELA(indAL);
index.indAR = indELA(indAR);
index.indAM = indELA(indAM);

index.indYApL = indELA(indYApL);
index.indYApR = indELA(indYApR);
index.indYApM = indELA(indYApM);

index.indYAmL = indELA(indYAmL);
index.indYAmR = indELA(indYAmR);
index.indYAmM = indELA(indYAmM);
