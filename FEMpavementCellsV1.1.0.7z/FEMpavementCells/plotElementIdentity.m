% this script can be used to display elements with different element
% identity value using different colors
% run main function first: mainFunction_FEMpavementCells
close all
cols = unique(ELidentity);
cmap = jet(numel(cols));
ELidCmap = 0;
faces = face_connectivity(LE); 
ind =1; %  index of iteration
tot = 1; % & - display a mesh with turgor pressure applied
elwise = 0; % if plot a mesh elementwise, set to 1; then you can plot only selected elements
alp = 0.1; % transparency% here you can select which elements will be displayed, 1:nel corresponds
nelPb = size(nodesPb,1); % number of elements in the periclinal bottom wall
nelPt = nelPb; % number of elements in the periclinal top wall first or second layer
nelA = size(nodesA,1); % number of elements in the Anticlinal wall 
nel = nelPb+ nelA + nelPt + nelPt ;
iter0 = 1:nel; % nel total number of elements,
%nelPb+1:nelA+nelPb+nelPt;%+nelA+1:nelPb+nelA+1*nelPt;
%IE= 1:nelPb+nelA+1%+2*nelPt:nelPb+nelA+3*nelPt%1:nel %number of elements 

cormat = XYZT{ind};
fh = figure ;
axis equal ;
hold on
unitfac = 1;

col0 = [242 155 0]/255; 
% col0 = 'none';
if tot
    patch('Vertices',cormat,'Faces',faces,...
    'FaceVertexCData',hsv(1),'FaceColor','none','EdgeColor',col0)
if elwise
        for IE = iter0
%         if ELidentity(IE) == 20 | ELidentity(IE) == -20 | ELidentity(IE) == -200
        set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
        patch('Vertices', cormat(LE(IE,:),:),'Faces',...
            [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',col0)  
%         end
        end
else
    patch('Vertices',cormat,'Faces',faces,...
    'FaceVertexCData',hsv(1),'FaceColor','none')
end
    alpha(0.3)
    view([60,37])
    set(gca,'visible','off')
else

    for IE = iter0
    %         if ELidentity(IE) == 20 | ELidentity(IE) == -20 | ELidentity(IE) == -200
    set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
    patch('Vertices', squeeze(XYZTcompatiblme{ind}(:,:,IE)),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',col0)     
    alpha(0.3)
    view([60,37])
    set(gca,'visible','off')
%             end
    end
        title('No Pressure')
    end
% end
%% visualize elements with different element identity value. 
% you can comment some if loops, so as to vizualize only  elements with the specific value
hold on
for IE = iter0
    elIdentity = ELidentity(IE);
%     select, which elements you want to visualize colors
  if(elIdentity == 1) | (elIdentity == 10) | (elIdentity == 11)...
    | (elIdentity == -213)| (elIdentity == -415)| (elIdentity == -617)| (elIdentity == -819)
elementscolor = 'b';

    set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
    patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',elementscolor)
  end
  if (elIdentity == sqrt(2)| (elIdentity == 110) | (elIdentity == 100))...
     | (elIdentity == -2) | (elIdentity == -4)| (elIdentity == -6)| (elIdentity == -8)
 elementscolor = 'r';
 
     set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
    patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',elementscolor)
  end
  
    if (elIdentity == sqrt(3)| (elIdentity == 101) | (elIdentity == 111))...
        | (elIdentity == -3) | (elIdentity == -5)| (elIdentity == -7)| (elIdentity == -9)
 elementscolor = 'g';
 
     set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
    patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',elementscolor)
    end

    if (elIdentity == 2) | (elIdentity == -20) | (elIdentity == 20) | (elIdentity == 200)...% periclinal left
     | (elIdentity == 4) | (elIdentity == -40)| (elIdentity == 40) | (elIdentity == 400)...
     | (elIdentity == 2000)| (elIdentity == 4000) | (elIdentity == -200)| (elIdentity == -400)
 elementscolor = 'm';
 
     set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
    patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',elementscolor)
    end
  
   if (elIdentity == 3) | (elIdentity == -30)| (elIdentity == 30) | (elIdentity == 300)...
       | (elIdentity == 5) | (elIdentity == -50)| (elIdentity == 50) | (elIdentity == 500)...
       | (elIdentity == 3000)| (elIdentity == 5000) | (elIdentity == -300)| (elIdentity == -500)
 elementscolor = 'y';
 
     set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
    patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',elementscolor)
   end
  
      if (elIdentity == 8) | (elIdentity == -80) | (elIdentity == 80) | (elIdentity == 800)...% periclinal left
     | (elIdentity == 8000)| (elIdentity == -800)
 elementscolor = 'c';
 
     set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
    patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',elementscolor)
      end
  
        
      if (elIdentity == 9) | (elIdentity == -90) | (elIdentity == 90) | (elIdentity == 900)...% periclinal left
     | (elIdentity == 9000)| (elIdentity == -900)
  elementscolor = 'k';
     set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
    patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',elementscolor)
     end
end