function [detjacobian,invjacobian,jacobian]=Jacobian3D(nnel,dshapedxi,dshapedeta,dshapedksi,xcoord,ycoord,zcoord)

%------------------------------------------------------------------------
%  Purpose:
%     determine the Jacobian for three-dimensional mapping
%
%  Synopsis:
%     [detjacobian,invjacobian]=Jacobian(nnel,dshapedxi,dshapedeta,dshapedksi,xcoord,ycoord,zcoord 
%
%  Variable Description:
%     jacobian - Jacobian 
%     nnel - number of nodes per element   
%     dshapedxi - derivative of shape functions w.r.t. natural coordinate xi
%     dshapedeta - derivative of shape functions w.r.t. natural coordinate eta
%     dshapedksi - derivative of shape functions w.r.t. natural coordinate
%     ksi
%     xcoord - x axis coordinate values of nodes
%     ycoord - y axis coordinate values of nodes
% .   zcoord - z axis coordinate values of nodes
%------------------------------------------------------------------------

 jacobian=zeros(3,3);

 for i=1:nnel
 jacobian(1,1) = jacobian(1,1)+dshapedxi(i)*xcoord(i);
 jacobian(1,2) = jacobian(1,2)+dshapedxi(i)*ycoord(i);
 jacobian(1,3) = jacobian(1,3)+dshapedxi(i)*zcoord(i);
 
 jacobian(2,1) = jacobian(2,1)+dshapedeta(i)*xcoord(i);
 jacobian(2,2) = jacobian(2,2)+dshapedeta(i)*ycoord(i);
 jacobian(2,3) = jacobian(2,3)+dshapedeta(i)*zcoord(i);
 
 jacobian(3,1) = jacobian(3,1)+dshapedksi(i)*xcoord(i);
 jacobian(3,2) = jacobian(3,2)+dshapedksi(i)*ycoord(i);
 jacobian(3,3) = jacobian(3,3)+dshapedksi(i)*zcoord(i);
 
 end

 detjacobian = det(jacobian) ;  % Determinant of Jacobian matrix
 invjacobian = inv(jacobian) ;  % Inverse of Jacobian matrix