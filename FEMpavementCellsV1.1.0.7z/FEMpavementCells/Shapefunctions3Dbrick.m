function [shape,dshapedxi,dshapedeta,dshapedksi]=Shapefunctions3Dbrick(xi,eta,ksi)

%------------------------------------------------------------------------
%  Purpose:
%     compute 3D isoparametric 8-node brick shape functions
%     and their derivatves at the selected (integration) point
%     in terms of the natural coordinate 
%
%  Synopsis:
%     [shape,dshapedxi,dshapedeta]=shapefunctions(xi,eta,ksi)  
%
%  Variable Description:
%     shape - shape functions for four-node element
%     dshapedxi - derivatives of the shape functions w.r.t. xi
%     dshapedeta - derivatives of the shape functions w.r.t. eta
%     xi - xi coordinate value of the selected point   
%     eta -eta coordinate value of the selected point
%
%  Notes:
%     1st node at (-1,-1,-1), 2nd node at (1,-1,-1)
%     3rd node at (1,1,-1), 4th node at (-1,1,-1)
% .   5th node at (-1,-1,1), 6st at (1,-1,1)
% .   7th node at (1,1,1), 8th node at (-1,1,1)
%------------------------------------------------------------------------
% xi =  [-1  1  1 -1 -1  1 1 -1];
% eta = [-1 -1  1  1 -1 -1 1  1];
% ksi = [-1 -1 -1 -1  1  1 1  1];

% shape functions

 shape(1)=0.125*(1-xi)*(1-eta)*(1-ksi);
 shape(2)=0.125*(1+xi)*(1-eta)*(1-ksi);
 shape(3)=0.125*(1+xi)*(1+eta)*(1-ksi);
 shape(4)=0.125*(1-xi)*(1+eta)*(1-ksi);
 shape(5)=0.125*(1-xi)*(1-eta)*(1+ksi);
 shape(6)=0.125*(1+xi)*(1-eta)*(1+ksi);
 shape(7)=0.125*(1+xi)*(1+eta)*(1+ksi);
 shape(8)=0.125*(1-xi)*(1+eta)*(1+ksi);

% derivatives

dshapedxi(1)= -0.125*(1-eta)*(1-ksi);
dshapedxi(2)=  0.125*(1-eta)*(1-ksi);
dshapedxi(3)=  0.125*(1+eta)*(1-ksi);
dshapedxi(4)= -0.125*(1+eta)*(1-ksi);
dshapedxi(5)= -0.125*(1-eta)*(1+ksi);
dshapedxi(6)=  0.125*(1-eta)*(1+ksi);
dshapedxi(7)=  0.125*(1+eta)*(1+ksi);
dshapedxi(8)= -0.125*(1+eta)*(1+ksi);

dshapedeta(1)=-0.125*(1-xi)*(1-ksi);
dshapedeta(2)=-0.125*(1+xi)*(1-ksi);
dshapedeta(3)= 0.125*(1+xi)*(1-ksi);
dshapedeta(4)= 0.125*(1-xi)*(1-ksi);
dshapedeta(5)=-0.125*(1-xi)*(1+ksi);
dshapedeta(6)=-0.125*(1+xi)*(1+ksi);
dshapedeta(7)= 0.125*(1+xi)*(1+ksi);
dshapedeta(8)= 0.125*(1-xi)*(1+ksi);

dshapedksi(1)=-0.125*(1-xi)*(1-eta);
dshapedksi(2)=-0.125*(1+xi)*(1-eta);
dshapedksi(3)=-0.125*(1+xi)*(1+eta);
dshapedksi(4)=-0.125*(1-xi)*(1+eta);
dshapedksi(5)= 0.125*(1-xi)*(1-eta);
dshapedksi(6)= 0.125*(1+xi)*(1-eta);
dshapedksi(7)= 0.125*(1+xi)*(1+eta);
dshapedksi(8)= 0.125*(1-xi)*(1+eta);
