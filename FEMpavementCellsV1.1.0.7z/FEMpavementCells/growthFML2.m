function disp = growthFML2(ELXY,elIdentity,dmet1,dmet2,PexoRA,PexoLA)
% This function implements the expanding beam growth model
%   The growth law depend on the element identity value, i.e. wheter it is
%   a periclinal, top, bottom, anticlinal faceing left of right cell, etc.
global WidthPectin PdemL PdemR PexoL PexoR PexpAV3D PexpZ PexpXY Pt2Gr Pt1GrZtop Pt1Gr

% calculate the elements egdes length, hexaedral element has 12 edges
L014 = sqrt( (ELXY(1,1) - ELXY(4,1))^2 + (ELXY(1,2) - ELXY(4,2))^2 + (ELXY(1,3) - ELXY(4,3))^2);
L015 = sqrt( (ELXY(1,1) - ELXY(5,1))^2 + (ELXY(1,2) - ELXY(5,2))^2 + (ELXY(1,3) - ELXY(5,3))^2);
L023 = sqrt( (ELXY(2,1) - ELXY(3,1))^2 + (ELXY(2,2) - ELXY(3,2))^2 + (ELXY(2,3) - ELXY(3,3))^2);
L026 = sqrt( (ELXY(2,1) - ELXY(6,1))^2 + (ELXY(2,2) - ELXY(6,2))^2 + (ELXY(2,3) - ELXY(6,3))^2);
L037 = sqrt( (ELXY(3,1) - ELXY(7,1))^2 + (ELXY(3,2) - ELXY(7,2))^2 + (ELXY(3,3) - ELXY(7,3))^2);
L048 = sqrt( (ELXY(4,1) - ELXY(8,1))^2 + (ELXY(4,2) - ELXY(8,2))^2 + (ELXY(4,3) - ELXY(8,3))^2);
L058 = sqrt( (ELXY(5,1) - ELXY(8,1))^2 + (ELXY(5,2) - ELXY(8,2))^2 + (ELXY(5,3) - ELXY(8,3))^2);
L067 = sqrt( (ELXY(6,1) - ELXY(7,1))^2 + (ELXY(6,2) - ELXY(7,2))^2 + (ELXY(6,3) - ELXY(7,3))^2);
L012 = sqrt( (ELXY(1,1) - ELXY(2,1))^2 + (ELXY(1,2) - ELXY(2,2))^2 + (ELXY(1,3) - ELXY(2,3))^2);
L034 = sqrt( (ELXY(3,1) - ELXY(4,1))^2 + (ELXY(3,2) - ELXY(4,2))^2 + (ELXY(3,3) - ELXY(4,3))^2);
L056 = sqrt( (ELXY(5,1) - ELXY(6,1))^2 + (ELXY(5,2) - ELXY(6,2))^2 + (ELXY(5,3) - ELXY(6,3))^2);
L078 = sqrt( (ELXY(7,1) - ELXY(8,1))^2 + (ELXY(7,2) - ELXY(8,2))^2 + (ELXY(7,3) - ELXY(8,3))^2);
% anticlinal wall brick element [1 2 3 4 5 6 7 8]
% 24 dof, node 1: dof 1,2,3; node 2: dof 4,5,6 etc  
% use plotElementIdentity.m script to vusualize elements with different element identity value
disp = zeros(24,1);
if (elIdentity == 1) | (elIdentity == 10) | (elIdentity == 11)...
   | (elIdentity == -213)| (elIdentity == -415)| (elIdentity == -617)| (elIdentity == -819)
%node 1
disp(1) = -PexoLA*WidthPectin - PexoLA*PexpXY*dmet2;
disp(2) =  -(L014 * PexoLA * dmet2 * PexpXY)/2;
disp(3) = (L015*PexoLA*dmet2*PexpZ)/2;
% node 2
disp(4) = PexoRA*WidthPectin + PexoRA*PexpXY*dmet1;
disp(5) =  -(L023 * PexoRA * dmet1 * PexpXY)/2;
disp(6) = (L026*PexoRA*dmet1*PexpZ)/2;
% node 3
disp(7) = PexoRA*WidthPectin + PexoRA*PexpXY*dmet1;
disp(8) =   (L023 * PexoRA * dmet1 * PexpXY)/2; % opposite do disp(8)
disp(9) = (L037*PexoRA*dmet1*PexpZ)/2;
  %node 4
disp(10) = -PexoLA*WidthPectin - PexoLA*PexpXY*dmet2;
disp(11) =  (L014 * PexoLA * dmet2 * PexpXY)/2; % opposite to disp(2)
disp(12) = (L048*PexoLA*dmet2*PexpZ)/2;
  %node 5
disp(13) = -PexoLA*WidthPectin - PexoLA*PexpXY*dmet2;
disp(14) =  -(L058 * PexoLA * dmet2 * PexpXY)/2;
disp(15) =   -(L015*PexoLA*dmet2*PexpZ)/2;
% node 6
disp(16) = PexoRA*WidthPectin + PexoRA*PexpXY*dmet1;
disp(17) =  -(L067 * PexoRA * dmet1 * PexpXY)/2;
disp(18) =   -(L026*PexoRA*dmet1*PexpZ)/2;
% node 7
disp(19) = PexoRA*WidthPectin + PexoRA*PexpXY*dmet1;
disp(20) =   (L067 * PexoRA * dmet1 * PexpXY)/2;
disp(21) =   -(L037*PexoRA*dmet1*PexpZ)/2;
%node 8
disp(22) = -PexoLA*WidthPectin - PexoLA*PexpXY*dmet2;
disp(23) =  (L058 * PexoLA * dmet2 * PexpXY)/2;
disp(24) =  -(L048*PexoLA*dmet2*PexpZ)/2;
elseif (elIdentity == sqrt(2)| (elIdentity == 110) | (elIdentity == 100))...
     | (elIdentity == -2) | (elIdentity == -4)| (elIdentity == -6)| (elIdentity == -8)
%node 1
disp(1) = -PexoLA*WidthPectin - PexoLA*PexpXY*dmet2;
disp(2) =  -(L014 * PexoLA * dmet2 * PexpXY)/2;
disp(3) = (L015*PexoLA*dmet2*PexpZ)/2;
% node 2
disp(4) = PexoLA*WidthPectin + PexoLA*PexpXY*dmet2;
disp(5) =  -(L023 * PexoLA * dmet2 * PexpXY)/2;
disp(6) = (L026*PexoLA*dmet2*PexpZ)/2;
% node 3
disp(7) = PexoLA*WidthPectin + PexoLA*PexpXY*dmet2;
disp(8) =   (L023 * PexoLA * dmet2 * PexpXY)/2; % opposite do disp(8)
disp(9) = (L037*PexoLA*dmet2*PexpZ)/2;
  %node 4
disp(10) = -PexoLA*WidthPectin - PexoLA*PexpXY*dmet2;
disp(11) =  (L014 * PexoLA * dmet2 * PexpXY)/2; % opposite to disp(2)
disp(12) = (L048*PexoLA*dmet2*PexpZ)/2;
  %node 5
disp(13) = -PexoLA*WidthPectin - PexoLA*PexpXY*dmet2;
disp(14) =  -(L058 * PexoLA * dmet2 * PexpXY)/2;
disp(15) =   -(L015*PexoLA*dmet2*PexpZ)/2;
% node 6
disp(16) = PexoLA*WidthPectin + PexoLA*PexpXY*dmet2;
disp(17) =  -(L067 * PexoLA * dmet2 * PexpXY)/2;
disp(18) =   -(L026*PexoLA*dmet2*PexpZ)/2;
% node 7
disp(19) = PexoLA*WidthPectin + PexoLA*PexpXY*dmet2;
disp(20) =   (L067 * PexoLA * dmet2 * PexpXY)/2;
disp(21) =   -(L037*PexoLA*dmet2*PexpZ)/2;
%node 8
disp(22) = -PexoLA*WidthPectin - PexoLA*PexpXY*dmet2;
disp(23) =  (L058 * PexoLA * dmet2 * PexpXY)/2;
disp(24) =  -(L048*PexoLA*dmet2*PexpZ)/2;
elseif (elIdentity == sqrt(3)| (elIdentity == 101) | (elIdentity == 111))...
        | (elIdentity == -3) | (elIdentity == -5)| (elIdentity == -7)| (elIdentity == -9)
%node 1
disp(1) = -PexoRA*WidthPectin - PexoRA*PexpXY*dmet1;
disp(2) =  -(L014 * PexoRA * dmet1 * PexpXY)/2;
disp(3) = (L015*PexoRA*dmet1*PexpZ)/2;
% node 2
disp(4) = PexoRA*WidthPectin + PexoRA*PexpXY*dmet1;
disp(5) =  -(L023 * PexoRA * dmet1 * PexpXY)/2;
disp(6) = (L026*PexoRA*dmet1*PexpZ)/2;
% node 3
disp(7) = PexoRA*WidthPectin + PexoRA*PexpXY*dmet1;
disp(8) =   (L023 * PexoRA * dmet1 * PexpXY)/2; % opposite do disp(8)
disp(9) = (L037*PexoRA*dmet1*PexpZ)/2;
  %node 4
disp(10) = -PexoRA*WidthPectin - PexoRA*PexpXY*dmet1;
disp(11) =  (L014 * PexoRA * dmet1 * PexpXY)/2; % opposite to disp(2)
disp(12) = (L048*PexoRA*dmet1*PexpZ)/2;
  %node 5
disp(13) = -PexoRA*WidthPectin - PexoRA*PexpXY*dmet1;
disp(14) =  -(L058 * PexoRA * dmet1 * PexpXY)/2;
disp(15) =   -(L015*PexoRA*dmet1*PexpZ)/2;
% node 6
disp(16) = PexoRA*WidthPectin + PexoRA*PexpXY*dmet1;
disp(17) =  -(L067 * PexoRA * dmet1 * PexpXY)/2;
disp(18) =   -(L026*PexoRA*dmet1*PexpZ)/2;
% node 7
disp(19) = PexoRA*WidthPectin + PexoRA*PexpXY*dmet1;
disp(20) =   (L067 * PexoRA * dmet1 * PexpXY)/2;
disp(21) =   -(L037*PexoRA*dmet1*PexpZ)/2;
%node 8
disp(22) = -PexoRA*WidthPectin - PexoRA*PexpXY*dmet1;
disp(23) =  (L058 * PexoRA * dmet1 * PexpXY)/2;
disp(24) =  -(L048*PexoRA*dmet1*PexpZ)/2;
% periclinal left  bottom and first top
elseif (elIdentity == 2) | (elIdentity == -20) | (elIdentity == 20) | (elIdentity == 200)...% periclinal left
     | (elIdentity == 4) | (elIdentity == -40)| (elIdentity == 40) | (elIdentity == 400)...
     | (elIdentity == 2000)| (elIdentity == 4000) | (elIdentity == -200)| (elIdentity == -400)
% node1
disp(1) = -L012*PexoL*PdemL*PexpAV3D/2;
disp(2) = -L014*PexoL*PdemL*PexpAV3D/2;
disp(3) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
%node2
disp(4) = L012*PexoL*PdemL*PexpAV3D/2;
disp(5) = -L023*PexoL*PdemL*PexpAV3D/2;
disp(6) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
%node3
disp(7) = L034*PexoL*PdemL*PexpAV3D/2;
disp(8) = L023*PexoL*PdemL*PexpAV3D/2;
disp(9) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
%node4
disp(10) = -L034*PexoL*PdemL*PexpAV3D/2;
disp(11) = L014*PexoL*PdemL*PexpAV3D/2;
disp(12) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
%node5
disp(13) = -L056*PexoL*PdemL*PexpAV3D/2;
disp(14) = -L058*PexoL*PdemL*PexpAV3D/2;
if Pt1GrZtop
disp(15) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
end
%node6
disp(16) = L056*PexoL*PdemL*PexpAV3D/2;
disp(17) = -L067*PexoL*PdemL*PexpAV3D/2;
if Pt1GrZtop
disp(18) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
end
%node7
disp(19) = L078*PexoL*PdemL*PexpAV3D/2;
disp(20) = L067*PexoL*PdemL*PexpAV3D/2;
if Pt1GrZtop
disp(21) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
end
%node8
disp(22) = -L078*PexoL*PdemL*PexpAV3D/2;
disp(23) = L058*PexoL*PdemL*PexpAV3D/2;
if Pt1GrZtop
disp(24) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
end
% periclinal  right
elseif (elIdentity == 3) | (elIdentity == -30)| (elIdentity == 30) | (elIdentity == 300)...
       | (elIdentity == 5) | (elIdentity == -50)| (elIdentity == 50) | (elIdentity == 500)...
       | (elIdentity == 3000)| (elIdentity == 5000) | (elIdentity == -300)| (elIdentity == -500)
% node1
disp(1) = -L012*PexoR*PdemR*PexpAV3D/2;
disp(2) = -L014*PexoR*PdemR*PexpAV3D/2;
disp(3) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
%node2
disp(4) = L012*PexoR*PdemR*PexpAV3D/2;
disp(5) = -L023*PexoR*PdemR*PexpAV3D/2;
disp(6) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
%node3
disp(7) = L034*PexoR*PdemR*PexpAV3D/2;
disp(8) = L023*PexoR*PdemR*PexpAV3D/2;
disp(9) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
%node4
disp(10) = -L034*PexoR*PdemR*PexpAV3D/2;
disp(11) = L014*PexoR*PdemR*PexpAV3D/2;
disp(12) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
%node5
disp(13) = -L056*PexoR*PdemR*PexpAV3D/2;
disp(14) = -L058*PexoR*PdemR*PexpAV3D/2;
if Pt1GrZtop
disp(15) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
end
%node6
disp(16) = L056*PexoR*PdemR*PexpAV3D/2;
disp(17) = -L067*PexoR*PdemR*PexpAV3D/2;
if Pt1GrZtop
disp(18) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
end
%node7
disp(19) = L078*PexoR*PdemR*PexpAV3D/2;
disp(20) = L067*PexoR*PdemR*PexpAV3D/2;
if Pt1GrZtop
disp(21) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
end
%node8
disp(22) = -L078*PexoR*PdemR*PexpAV3D/2;
disp(23) = L058*PexoR*PdemR*PexpAV3D/2;
if Pt1GrZtop
disp(24) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
end
% periclinal left third layer
elseif (elIdentity == 6) | (elIdentity == -60) | (elIdentity == 60) | (elIdentity == 600)...% periclinal left
     | (elIdentity == 6000)| (elIdentity == -600)
 if Pt2Gr
    % node1
    disp(1) = -L012*PexoL*PdemL*PexpAV3D/2;
    disp(2) = -L014*PexoL*PdemL*PexpAV3D/2;
    disp(3) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
    %node2
    disp(4) = L012*PexoL*PdemL*PexpAV3D/2;
    disp(5) = -L023*PexoL*PdemL*PexpAV3D/2;
    disp(6) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
    %node3
    disp(7) = L034*PexoL*PdemL*PexpAV3D/2;
    disp(8) = L023*PexoL*PdemL*PexpAV3D/2;
    disp(9) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
    %node4
    disp(10) = -L034*PexoL*PdemL*PexpAV3D/2;
    disp(11) = L014*PexoL*PdemL*PexpAV3D/2;
    disp(12) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
    %node5
    disp(13) = -L056*PexoL*PdemL*PexpAV3D/2;
    disp(14) = -L058*PexoL*PdemL*PexpAV3D/2;
    disp(15) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
    %node6
    disp(16) = L056*PexoL*PdemL*PexpAV3D/2;
    disp(17) = -L067*PexoL*PdemL*PexpAV3D/2;
    disp(18) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
    %node7
    disp(19) = L078*PexoL*PdemL*PexpAV3D/2;
    disp(20) = L067*PexoL*PdemL*PexpAV3D/2;
    disp(21) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
    %node8
    disp(22) = -L078*PexoL*PdemL*PexpAV3D/2;
    disp(23) = L058*PexoL*PdemL*PexpAV3D/2;
    disp(24) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
end
% periclinal  right
elseif (elIdentity == 7) | (elIdentity == -70) | (elIdentity == 70) | (elIdentity == 700)...% periclinal left
     | (elIdentity == 7000)| (elIdentity == -700)
% node1
if Pt2Gr
    disp(1) = -L012*PexoR*PdemR*PexpAV3D/2;
    disp(2) = -L014*PexoR*PdemR*PexpAV3D/2;
    disp(3) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
    %node2
    disp(4) = L012*PexoR*PdemR*PexpAV3D/2;
    disp(5) = -L023*PexoR*PdemR*PexpAV3D/2;
    disp(6) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
    %node3
    disp(7) = L034*PexoR*PdemR*PexpAV3D/2;
    disp(8) = L023*PexoR*PdemR*PexpAV3D/2;
    disp(9) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
    %node4
    disp(10) = -L034*PexoR*PdemR*PexpAV3D/2;
    disp(11) = L014*PexoR*PdemR*PexpAV3D/2;
    disp(12) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
    %node5
    disp(13) = -L056*PexoR*PdemR*PexpAV3D/2;
    disp(14) = -L058*PexoR*PdemR*PexpAV3D/2;
    disp(15) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
    %node6
    disp(16) = L056*PexoR*PdemR*PexpAV3D/2;
    disp(17) = -L067*PexoR*PdemR*PexpAV3D/2;
    disp(18) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
    %node7
    disp(19) = L078*PexoR*PdemR*PexpAV3D/2;
    disp(20) = L067*PexoR*PdemR*PexpAV3D/2;
    disp(21) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
    %node8
    disp(22) = -L078*PexoR*PdemR*PexpAV3D/2;
    disp(23) = L058*PexoR*PdemR*PexpAV3D/2;
    disp(24) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
    elseif (elIdentity == 8) | (elIdentity == -80) | (elIdentity == 80) | (elIdentity == 800)...% periclinal left
     | (elIdentity == 8000)| (elIdentity == -800)
 if Pt1Gr
     % node1
    disp(1) = -L012*PexoL*PdemL*PexpAV3D/2;
    disp(2) = -L014*PexoL*PdemL*PexpAV3D/2;
    disp(3) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
    %node2
    disp(4) = L012*PexoL*PdemL*PexpAV3D/2;
    disp(5) = -L023*PexoL*PdemL*PexpAV3D/2;
    disp(6) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
    %node3
    disp(7) = L034*PexoL*PdemL*PexpAV3D/2;
    disp(8) = L023*PexoL*PdemL*PexpAV3D/2;
    disp(9) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
    %node4
    disp(10) = -L034*PexoL*PdemL*PexpAV3D/2;
    disp(11) = L014*PexoL*PdemL*PexpAV3D/2;
    disp(12) = -PexoL*WidthPectin - PexoL*PdemL*PexpAV3D;
    %node5
    disp(13) = -L056*PexoL*PdemL*PexpAV3D/2;
    disp(14) = -L058*PexoL*PdemL*PexpAV3D/2;
    disp(15) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
    %node6
    disp(16) = L056*PexoL*PdemL*PexpAV3D/2;
    disp(17) = -L067*PexoL*PdemL*PexpAV3D/2;
    disp(18) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
    %node7
    disp(19) = L078*PexoL*PdemL*PexpAV3D/2;
    disp(20) = L067*PexoL*PdemL*PexpAV3D/2;
    disp(21) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
    %node8
    disp(22) = -L078*PexoL*PdemL*PexpAV3D/2;
    disp(23) = L058*PexoL*PdemL*PexpAV3D/2;
    disp(24) = PexoL*WidthPectin + PexoL*PdemL*PexpAV3D;
end
% periclinal  right
elseif (elIdentity == 9) | (elIdentity == -90) | (elIdentity == 90) | (elIdentity == 900)...% periclinal left
     | (elIdentity == 9000)| (elIdentity == -900)
 % node1
if Pt1Gr
    disp(1) = -L012*PexoR*PdemR*PexpAV3D/2;
    disp(2) = -L014*PexoR*PdemR*PexpAV3D/2;
    disp(3) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
    %node2
    disp(4) = L012*PexoR*PdemR*PexpAV3D/2;
    disp(5) = -L023*PexoR*PdemR*PexpAV3D/2;
    disp(6) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
    %node3
    disp(7) = L034*PexoR*PdemR*PexpAV3D/2;
    disp(8) = L023*PexoR*PdemR*PexpAV3D/2;
    disp(9) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
    %node4
    disp(10) = -L034*PexoR*PdemR*PexpAV3D/2;
    disp(11) = L014*PexoR*PdemR*PexpAV3D/2;
    disp(12) = -PexoR*WidthPectin - PexoR*PdemR*PexpAV3D;
    %node5
    disp(13) = -L056*PexoR*PdemR*PexpAV3D/2;
    disp(14) = -L058*PexoR*PdemR*PexpAV3D/2;
    disp(15) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
    %node6
    disp(16) = L056*PexoR*PdemR*PexpAV3D/2;
    disp(17) = -L067*PexoR*PdemR*PexpAV3D/2;
    disp(18) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
    %node7
    disp(19) = L078*PexoR*PdemR*PexpAV3D/2;
    disp(20) = L067*PexoR*PdemR*PexpAV3D/2;
    disp(21) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
    %node8
    disp(22) = -L078*PexoR*PdemR*PexpAV3D/2;
    disp(23) = L058*PexoR*PdemR*PexpAV3D/2;
    disp(24) = PexoR*WidthPectin + PexoR*PdemR*PexpAV3D;
end
end
end

