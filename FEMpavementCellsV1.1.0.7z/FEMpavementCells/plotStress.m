close all
stressINT_G = zeros(6,nel);
stressINT = zeros(6,nel);
flag = 0;
for eli = 1:8:size(outG.SIGMA,2)
    flag = flag + 1;
    stressINT_G(:,flag) = mean(outG.SIGMA(:,eli:eli+7),2);
    stressINT(:,flag) = mean(out.SIGMA(:,eli:eli+7),2);
end
%%
st = 1;
trc = 0;
% min(stressINT_G(st));
faces = face_connectivity(LE); 
ind = 200;
tot = 0;
normv = 0;
ind0 = 1+nelPb+nelA+nelPt:nelPb++nelA+2*nelPt;%:1:nelPb+nelA;
cormat = XYZT{ind};%Cor;%{1};
fh = figure ;
axis equal ;
hold on
unitfac = 1;
% stress = stressINT(st,:);
if tot
    for IE=ind0%nelPb+nelA%+nelPt %number of elements   
        x = cormat(LE(IE,:),1);         
        y = cormat(LE(IE,:),2);  
        z = cormat(LE(IE,:),3);  

        i1 = [1,4,3,2];
        i2 = [5,6,7,8];
        i3 = [1,2,6,5];
        i4 = [4,8,7,3];
        i5 = [1,5,8,4];
        i6 = [2,3,7,6];

        fx1 = x(i1);    fy1 = y(i1);   fz1 = z(i1);
        fx2 = x(i2);    fy2 = y(i2);   fz2 = z(i2);
        fx3 = x(i3);    fy3 = y(i3);   fz3 = z(i3);
        fx4 = x(i4);    fy4 = y(i4);   fz4 = z(i4);
        fx5 = x(i5);    fy5 = y(i5);   fz5 = z(i5);
        fx6 = x(i6);    fy6 = y(i6);   fz6 = z(i6);
        if trc
            %  Stress = 2nd PK stress [S11, S22, S33, S12, S23, S13];
            strmat = [stressINT(1,IE),stressINT(4,IE),stressINT(6,IE);...
                stressINT(4,IE),stressINT(2,IE),stressINT(5,IE);...
                stressINT(6,IE),stressINT(5,IE),stressINT(3,IE)];
            var = sum(eig(strmat));
        else
        var = stressINT(st,IE); 
        end
        hh  = fill3(fx1', fy1', fz1', var, 'LineWidth', 0.5);
        hh  = fill3(fx2', fy2', fz2', var, 'LineWidth', 0.5);
        hh  = fill3(fx3', fy3', fz3', var, 'LineWidth', 0.5);
        hh  = fill3(fx4', fy4', fz4', var, 'LineWidth', 0.5);
        hh  = fill3(fx5', fy5', fz5', var, 'LineWidth', 0.5);
        hh  = fill3(fx6', fy6', fz6', var, 'LineWidth', 0.5);
    end
else

    for IE=1:nel%nelPb+nelA%+nelPt %number of elements 
        x = squeeze(XYZTcompatiblme{ind}(:,1,IE));         
        y = squeeze(XYZTcompatiblme{ind}(:,2,IE));  
        z = squeeze(XYZTcompatiblme{ind}(:,3,IE));  

        i1 = [1,4,3,2];
        i2 = [5,6,7,8];
        i3 = [1,2,6,5];
        i4 = [4,8,7,3];
        i5 = [1,5,8,4];
        i6 = [2,3,7,6];

        fx1 = x(i1);    fy1 = y(i1);   fz1 = z(i1);
        fx2 = x(i2);    fy2 = y(i2);   fz2 = z(i2);
        fx3 = x(i3);    fy3 = y(i3);   fz3 = z(i3);
        fx4 = x(i4);    fy4 = y(i4);   fz4 = z(i4);
        fx5 = x(i5);    fy5 = y(i5);   fz5 = z(i5);
        fx6 = x(i6);    fy6 = y(i6);   fz6 = z(i6);

        if trc
               strmat = [stressINT_G(1,IE),stressINT_G(4,IE),stressINT_G(6,IE);...
                stressINT_G(4,IE),stressINT_G(2,IE),stressINT_G(5,IE);...
                stressINT_G(6,IE),stressINT_G(5,IE),stressINT_G(3,IE)];
            var = sum(eig(strmat));
        else
        var = stressINT_G(st,IE); 
        end
        hh  = fill3(fx1', fy1', fz1', var, 'LineWidth', 0.5);
        hh  = fill3(fx2', fy2', fz2', var, 'LineWidth', 0.5);
        hh  = fill3(fx3', fy3', fz3', var, 'LineWidth', 0.5);
        hh  = fill3(fx4', fy4', fz4', var, 'LineWidth', 0.5);
        hh  = fill3(fx5', fy5', fz5', var, 'LineWidth', 0.5);
        hh  = fill3(fx6', fy6', fz6', var, 'LineWidth', 0.5);

    end
end

newmap = b2r(min(stressINT_G(st,:)),max(stressINT_G(st,:)),1024);
colormap(newmap)
colorbar
 set(gca,'visible','off')
%%
% caxis([-1 1]*10^(-12))