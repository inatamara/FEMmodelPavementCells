% run main function first: mainFunction_FEMpavementCells
% This script permits to plot a FEM mesh at each growth iteration step (ind). 
% You can plot either a mesh with tourgor pressure (cormat = XYZT{ind}),
% then set a variable tot = 1; you can also plot a compatible growth mesh
% without turgor pressure applied, then set tot = 0;
cols = unique(ELidentity);
cmap = jet(numel(cols));
ELidCmap = 0;
faces = face_connectivity(LE); % LE node connectivity matrix
ind =200; %  index iteration
tot = 1; % & - display a mesh with turgor pressure applied
elwise = 0; % if plot a mesh elementwise, set to 1; then you can plot only selected elements
alp = 0.1; % transparency
nelPb = size(nodesPb,1); % number of elements in the periclinal bottom wall
nelPt = nelPb; % number of elements in the periclinal top wall first or second layer
nelA = size(nodesA,1); % number of elements in the Anticlinal wall 
nel = nelPb+ nelA + nelPt + nelPt ;
% here you can select which elements will be displayed, 1:nel corresponds
% to all elements
iter0 = 1:nel; % nel total number of elements, 
%nelPb+nelA+nelPb +1:nelA+nelPb+nelPt+NxT;%1:nel;%nelPb+1:nelA+nelPb+nelPt;%+nelA+1:nelPb+nelA+1*nelPt;
%1:nelPb+nelA+1%+2*nelPt:nelPb+nelA+3*nelPt%1:nel %number of elements 
normv = 0;
cormat = XYZT{ind};%Cor;%{1};
fh = figure ;
axis equal ;
hold on
unitfac = 1;
% color of the mesh
% col0 = [64 169 130]/255; % oldwt
% col0 = [217 192 255]/255; old pme
% col0 = [39 0 54]/255; %old pme
% col0 = [204, 86, 43]/255;%pmei newest
% col0 = [109 166 123]/255;% old wt
% col0 = [242 155 0]/255; %pmei
% col0 = 'none';
% col1 = [161, 98, 76]/255;% pmei
% col0 = [108 77 179]/255; %pme
col0 = [0 56 64]/255; % wt 
if tot
    patch('Vertices',cormat,'Faces',faces,...
    'FaceVertexCData',hsv(1),'EdgeColor',col0,'FaceColor','none')
if elwise % plot mesh elementwise, it may take some time
        for IE = iter0 % plot selected elements
%         if ELidentity(IE) == 20 | ELidentity(IE) == -20 | ELidentity(IE)
%         == -200 here you can select, which elements will be displayed, by
%         choseing elements with given element identity value
        set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
        patch('Vertices', cormat(LE(IE,:),:),'Faces',...
            [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',col0,'EdgeColor',col0)  
%         end
        end
else
    patch('Vertices',cormat,'Faces',faces,...
    'FaceVertexCData',hsv(1),'FaceColor',col0,'EdgeColor',col0,'FaceAlpha',alp)%,'FaceVertexAlphaData',alp
end
%     alpha(alp)
axis([-500 1200 -1000 2000])
view([67,40])
set(gca,'visible','off')
else % compatible growth without Turgor

    for IE = iter0 % plot selected elements
%         if ELidentity(IE) == 20 | ELidentity(IE) == -20 | ELidentity(IE) == -200
        set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
        patch('Vertices', squeeze(XYZTcompatiblme{ind}(:,:,IE)),'Faces',...
            [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',col0,'EdgeColor',col0,'FaceAlpha',alp)     
%             alpha(0.1)
        axis([-500 1200 -1000 2000])
        view([67,40])
        set(gca,'visible','off')
    end
        title('No Pressure')
    end
% end
width = 4;% Width in inches
height = 4; %height in inches

pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1)-100 pos(2)-100 width*80, height*80]); %<- Set size
set(gcf,'color','w')
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
%%
width = 2;% Width in inches
height = 2; %height in inches
alw=1.5;% AxesLineWidth
fsz=10; % Fontsize
lw=3;%  % LineWidth
msz=15; % MarkerSize
fszl=8; % Fontsize legend
fontname='Helvetica'; % Fontsize name
tickdir = 'out';
ticksize= [0.02 0.035]; % Fontsize legend
figure;plot(Dmet1,'LineWidth',lw);hold on;plot(Dmet2,'LineWidth',lw);

set(gca,'TickDir', tickdir);
set(gca,'TickLength', ticksize); 
set(gca, 'FontSize', fsz, 'LineWidth', alw); 
set(gca,'box','off');
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1)-100 pos(2)-100 width*80, height*80]); %<- Set size
set(gcf,'color','w')
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');


