
nodA = sort(unique(nodesA(:)));
nodPb = sort(unique(nodesPb(:)));
nodPt = sort(unique(nodesPt(:)));
nodPt2 = sort(unique(nodesPt2(:)));
% nodPt1 = sort(unique(nodesPt1(:)));
% bcs for boundary elements for peric top and bottom in x y
% y bc bottom peric in -y dir
bcYmPb = [1:npxt,npxt*npy+1:npxt*npy+npxt];
% y bc bottom peric in +y dir
bcYpPb = [npxt*npy-npx:npxt*npy,2*npxt*npy-npx:2*npxt*npy];
% x bc bottom peric in -x dir
bcXmPb = [1:npxt:npxt*npy-npx,npxt*npy+1:npxt:2*npxt*npy-npx];
% bcXmPb = [1,npxt*npy-npx,npxt*npy+1,2*npxt*npy-npx];
% x bc bottom peric in +x dir
% bcXpPb = [npxt,npxt*npy,npxt*npy+npxt,2*npxt*npy];
% x bc bottom peric in +x dir
bcXpPb = [npxt:npxt:npxt*npy,npxt*npy+npxt:npxt:2*npxt*npy];
Xpar = 2;
% bcs for boundary elements of anticloinal wall in y direction
% anticlinal border elements x bc, those with Elidentity = 10, 11
%%
bcXmA100 = LE(find((ELidentity == 100)),:); 
bcXmA100 = unique(bcXmA100(:));
bcXmA110 = LE(find((ELidentity == 110)),:); 
bcXmA110 = unique(bcXmA110(:));

bcXpA101 = LE(find((ELidentity == 101)),:); 
bcXpA101 = unique(bcXpA101(:));
bcXpA111 = LE(find((ELidentity == 111)),:); 
bcXpA111 = unique(bcXpA111(:));

constrainsAXm = sort([bcXmA100(1:4:end);bcXmA110(3:4:end)]);
constrainsAXp = sort([bcXpA101(2:4:end);bcXpA111(4:4:end)]);

SDISPTAXp(1:numel(constrainsAXp),1) = constrainsAXp';
SDISPTAXp(:,2) = ones(numel(constrainsAXp),1);
SDISPTAXp(:,3) = zeros(numel(constrainsAXp),1);

SDISPTAXm(1:numel(constrainsAXm),1) = constrainsAXm';
SDISPTAXm(:,2) = ones(numel(constrainsAXm),1);
SDISPTAXm(:,3) = zeros(numel(constrainsAXm),1);
%%
 % second periclinal layer Z BCs along the x edge (perpendicular to
 % anticlinal wall)
 %index.indYPt2BCLB % ELind 6000
 % index.indYPt2BCRB % ELind 7000
%  
%  nodePt2XmZ = [LE(index.indYPt2BCLB,[1,2,5,6]);...
%                LE(index.indYPt2BCRB,[1,2,5,6])];


%%
% anticlinal bc in -y
nodeAYmL = [LE(index.indYAmL,[1,2,5,6]);...
           LE(index.indPt100,[1,2,5,6]);...
           LE(index.indPt2_100,[1,2,5,6]);...
           LE(index.indPb100,[1,2,5,6])];
constrainsAYmL = unique(nodeAYmL(:),'stable');
SDISPTAYmL(1:numel(constrainsAYmL),1) = constrainsAYmL';
SDISPTAYmL(:,2) = repmat(2,[numel(constrainsAYmL),1]);
SDISPTAYmL(:,3) = zeros(numel(constrainsAYmL),1);

nodeAYmR = [LE(index.indYAmR,[1,2,5,6]);...
            LE(index.indPt101,[1,2,5,6]);...
            LE(index.indPt2_101,[1,2,5,6]);...
            LE(index.indPb101,[1,2,5,6])];
constrainsAYmR = unique(nodeAYmR(:),'stable');
SDISPTAYmR(1:numel(constrainsAYmR),1) = constrainsAYmR';
SDISPTAYmR(:,2) = repmat(2,[numel(constrainsAYmR),1]);
SDISPTAYmR(:,3) = zeros(numel(constrainsAYmR),1);
%%
% anticlinal bc in +y
nodeAYpL = [LE(index.indYApL,[3,4,7,8]);...
            LE(index.indPt110,[3,4,7,8]);...
           LE(index.indPt2_110,[3,4,7,8]);...
           LE(index.indPb110,[3,4,7,8])];
constrainsAYpL = unique(nodeAYpL(:),'stable');
SDISPTAYpL(1:numel(constrainsAYpL),1) = constrainsAYpL';
SDISPTAYpL(:,2) = repmat(2,[numel(constrainsAYpL),1]);
SDISPTAYpL(:,3) = zeros(numel(constrainsAYpL),1);

nodeAYpR = [LE(index.indYApR,[3,4,7,8]);...
            LE(index.indPt111,[3,4,7,8]);...
            LE(index.indPt2_111,[3,4,7,8]);...
            LE(index.indPb111,[3,4,7,8])];
constrainsAYpR = unique(nodeAYpR(:),'stable');
SDISPTAYpR(1:numel(constrainsAYpR),1) = constrainsAYpR';
SDISPTAYpR(:,2) = repmat(2,[numel(constrainsAYpR),1]);
SDISPTAYpR(:,3) = zeros(numel(constrainsAYpR),1);
%% constrains periclinal bottom
% exclude anticlinal Y border elements
% constrainsPbYm = setdiff(nodPb(bcYmPb),constrainsAYm,'stable');
% SDISPTPbYm(1:numel(constrainsPbYm),1) = constrainsPbYm';
% SDISPTPbYm(:,2) = repmat(2,[numel(constrainsPbYm),1]);
% SDISPTPbYm(:,3) = zeros(numel(constrainsPbYm),1);
% 
% constrainsPbYp = setdiff(nodPb(bcYpPb),constrainsAYp,'stable');
% SDISPTPbYp(1:numel(constrainsPbYp),1) = constrainsPbYp';
% SDISPTPbYp(:,2) = repmat(2,[numel(constrainsPbYp),1]);
% SDISPTPbYp(:,3) = zeros(numel(constrainsPbYp),1);

constrainsPbXm = nodPb(bcXmPb);
SDISPTPbXm(1:numel(constrainsPbXm),1) = constrainsPbXm';
SDISPTPbXm(:,2) = repmat(1,[numel(constrainsPbXm),1]);
SDISPTPbXm(:,3) = -Xpar;%zeros(numel(constrainsPbXm),1);

constrainsPbXp = nodPb(bcXpPb);
SDISPTPbXp(1:numel(constrainsPbXp),1) = constrainsPbXp';
SDISPTPbXp(:,2) = repmat(1,[numel(constrainsPbXp),1]);
SDISPTPbXp(:,3) = Xpar;%zeros(numel(constrainsPbXp),1);
% first periclinal layer
% constrainsPtYm = setdiff(nodPt(bcYmPb),constrainsAYm,'stable');
% SDISPTPtYm(1:numel(constrainsPtYm),1) = constrainsPtYm';
% SDISPTPtYm(:,2) = repmat(2,[numel(constrainsPtYm),1]);
% SDISPTPtYm(:,3) = zeros(numel(constrainsPtYm),1);
% 
% constrainsPtYp = setdiff(nodPt(bcYpPb),constrainsAYp,'stable');
% SDISPTPtYp(1:numel(constrainsPtYp),1) = constrainsPtYp';
% SDISPTPtYp(:,2) = repmat(2,[numel(constrainsPtYp),1]);
% SDISPTPtYp(:,3) = zeros(numel(constrainsPtYp),1);

constrainsPtXm = nodPt(bcXmPb);
SDISPTPtXm(1:numel(constrainsPtXm),1) = constrainsPtXm';
SDISPTPtXm(:,2) = ones(1,numel(constrainsPtXm))';
SDISPTPtXm(:,3) = -Xpar;%zeros(numel(constrainsPtXm),1);

constrainsPtXp = nodPt(bcXpPb);
SDISPTPtXp(1:numel(constrainsPtXp),1) = constrainsPtXp';
SDISPTPtXp(:,2) = ones(1,numel(constrainsPtXp))';
SDISPTPtXp(:,3) = Xpar;%zeros(numel(constrainsPtXp),1);

% third peric
% constrainsPt2Ym = setdiff(nodPt2(bcYmPb),[constrainsAYm;constrainsPtYm],'stable');
% SDISPTPt2Ym(1:numel(constrainsPt2Ym),1) = constrainsPt2Ym';
% SDISPTPt2Ym(:,2) = repmat(2,[numel(constrainsPt2Ym),1]);
% SDISPTPt2Ym(:,3) = zeros(numel(constrainsPt2Ym),1);
% 
% constrainsPt2Yp = setdiff(nodPt2(bcYpPb),[constrainsAYp;constrainsPtYp],'stable');
% SDISPTPt2Yp(1:numel(constrainsPt2Yp),1) = constrainsPt2Yp';
% SDISPTPt2Yp(:,2) = repmat(2,[numel(constrainsPt2Yp),1]);
% SDISPTPt2Yp(:,3) = zeros(numel(constrainsPt2Yp),1);

constrainsPt2Xm = setdiff(nodPt2(bcXmPb),constrainsPtXm,'stable');%nodPt1(bcXmPb);%nodPt2(bcXmPb);
SDISPTPt2Xm(1:numel(constrainsPt2Xm),1) = constrainsPt2Xm';
SDISPTPt2Xm(:,2) = ones(1,numel(constrainsPt2Xm))';
SDISPTPt2Xm(:,3) = -Xpar;%zeros(numel(constrainsPt2Xm),1);

constrainsPt2Xp = setdiff(nodPt2(bcXpPb),constrainsPtXp,'stable');
SDISPTPt2Xp(1:numel(constrainsPt2Xp),1) = constrainsPt2Xp';
SDISPTPt2Xp(:,2) = ones(1,numel(constrainsPt2Xp))';
SDISPTPt2Xp(:,3) = Xpar;%zeros(numel(constrainsPt2Xp),1);

% periclinal top border elements fixed in z
bcZmPt = [1:npxt:npxt*npy-npx,npxt:npxt:npxt*npy];
bcZpPt = [npxt*npy+1:npxt:2*npxt*npy-npx,npxt*npy+npxt:npxt:2*npxt*npy];
bcZpPt2 = [npxt*npy+1:npxt:2*npxt*npy-npx,npxt*npy+npxt:npxt:2*npxt*npy];
% bcZmPt = [1,npxt,npxt*npy-npx,npxt*npy];
% bcZpPt = [npxt*npy+1,2*npxt*npy-npx,npxt*npy+npxt,2*npxt*npy];
clear SDISPTPtZm SDISPTPtZp
% bcZmPt = unique([1:npxt,npxt*npy-npx:npxt*npy,1:npxt:npxt*npy-npx,npxt:npxt:npxt*npy]);
% bcZpPt = unique([npxt*npy+1:npxt*npy+npxt,2*npxt*npy-npx:2*npxt*npy,...
%     npxt*npy+1:npxt:2*npxt*npy-npx,npxt*npy+npxt:npxt:2*npxt*npy]);
% only third periclinal layer has elements constrained in z
constrainsPtZm = nodPt(bcZmPt);
SDISPTPtZm(1:numel(constrainsPtZm),1) = constrainsPtZm';
SDISPTPtZm(:,2) = repmat(3,[numel(constrainsPtZm),1]);
SDISPTPtZm(:,3) = zeros(numel(constrainsPtZm),1);

constrainsPtZp = nodPt(bcZpPt);
SDISPTPtZp(1:numel(constrainsPtZp),1) = constrainsPtZp';
SDISPTPtZp(:,2) = repmat(3,[numel(constrainsPtZp),1]);
SDISPTPtZp(:,3) = zeros(numel(constrainsPtZp),1);

% constrainsPt2Zm = nodPt2(bcZmPt);
% SDISPTPt2Zm(1:numel(constrainsPt2Zm),1) = constrainsPt2Zm';
% SDISPTPt2Zm(:,2) = repmat(3,[numel(constrainsPt2Zm),1]);
% SDISPTPt2Zm(:,3) = zeros(numel(constrainsPt2Zm),1);

constrainsPt2Zp = nodPt2(bcZpPt2);
SDISPTPt2Zp(1:numel(constrainsPt2Zp),1) = constrainsPt2Zp';
SDISPTPt2Zp(:,2) = repmat(3,[numel(constrainsPt2Zp),1]);
SDISPTPt2Zp(:,3) = zeros(numel(constrainsPt2Zp),1);

% writting bc for periclinal bottom in z direction, all bottom nodes do not
% move in z
constrainsPbZ = nodPb(1:2*npxt*npy);
SDISPTPbZ(1:numel(constrainsPbZ),1) = constrainsPbZ';
SDISPTPbZ(:,2) = repmat(3,[numel(constrainsPbZ),1]);
SDISPTPbZ(:,3) = zeros(numel(constrainsPbZ),1);

bcYmZmPt = [1:npxt];
bcYmZmPt = bcYmZmPt(2:end-1);
bcYmZpPt = [npxt*npy+1:npxt*npy+npxt];
bcYmZpPt = bcYmZpPt(2:end-1);

% first periclinal layer
constrainsPtYmZm = setdiff(nodPt(bcYmZmPt),[constrainsAYmL;constrainsAYmR;constrainsPtZm],'stable');
SDISPTPtYmZm(1:numel(constrainsPtYmZm),1) = constrainsPtYmZm';
SDISPTPtYmZm(:,2) = repmat(3,[numel(constrainsPtYmZm),1]);% 3 -  in Z direction
SDISPTPtYmZm(:,3) = zeros(numel(constrainsPtYmZm),1);

constrainsPtYmZp = setdiff(nodPt(bcYmZpPt),[constrainsAYmL;constrainsAYmR;constrainsPtZp],'stable');
SDISPTPtYmZp(1:numel(constrainsPtYmZp),1) = constrainsPtYmZp';
SDISPTPtYmZp(:,2) = repmat(3,[numel(constrainsPtYmZp),1]); % 3 -  in Z direction
SDISPTPtYmZp(:,3) = zeros(numel(constrainsPtYmZp),1);

bcYpPtZm = [npxt*npy-npx:npxt*npy];
bcYpPtZp = [2*npxt*npy-npx:2*npxt*npy];

constrainsPtYpZm = setdiff(nodPt(bcYpPtZm),[constrainsAYpL;constrainsAYpR;constrainsPtZm],'stable');
SDISPTPtYpZm(1:numel(constrainsPtYpZm),1) = constrainsPtYpZm';
SDISPTPtYpZm(:,2) = repmat(3,[numel(constrainsPtYpZm),1]);% 3 -  in Z direction
SDISPTPtYpZm(:,3) = zeros(numel(constrainsPtYpZm),1);

constrainsPtYpZp = setdiff(nodPt(bcYpPtZp),[constrainsAYpL;constrainsAYpR;constrainsPtZp],'stable');
SDISPTPtYpZp(1:numel(constrainsPtYpZp),1) = constrainsPtYpZp';
SDISPTPtYpZp(:,2) = repmat(3,[numel(constrainsPtYpZp),1]); % 3 -  in Z direction
SDISPTPtYpZp(:,3) = zeros(numel(constrainsPtYpZp),1);

constrainsPt2YpZp = setdiff(nodPt2(bcYpPtZp),[constrainsAYpL;constrainsAYpR;constrainsPt2Zp],'stable');
SDISPTPt2YpZp(1:numel(constrainsPt2YpZp),1) = constrainsPt2YpZp';
SDISPTPt2YpZp(:,2) = repmat(3,[numel(constrainsPt2YpZp),1]); % 3 -  in Z direction
SDISPTPt2YpZp(:,3) = zeros(numel(constrainsPt2YpZp),1);

constrainsPt2YmZp = setdiff(nodPt2(bcYmZpPt),[constrainsAYmL;constrainsAYmR;constrainsPt2Zp],'stable');
SDISPTPt2YmZp(1:numel(constrainsPt2YmZp),1) = constrainsPt2YmZp';
SDISPTPt2YmZp(:,2) = repmat(3,[numel(constrainsPt2YmZp),1]); % 3 -  in Z direction
SDISPTPt2YmZp(:,3) = zeros(numel(constrainsPt2YmZp),1);


% SDISPT = [;SDISPTAXp;SDISPTAXm;SDISPTAYmL;SDISPTAYpL;...%
%           SDISPTAYmR;SDISPTAYpR;...%
%           SDISPTPbXm;SDISPTPbXp;...%SDISPTPbYm;SDISPTPbYp;
%           SDISPTPtXm;SDISPTPtXp;...%SDISPTPtYm;SDISPTPtYp;
%           SDISPTPbZ;SDISPTPtZm;SDISPTPtZp;...%SDISPTPt1Ym;SDISPTPt1Yp;          SDISPTPt1Xm;SDISPTPt1Xp;...
%           SDISPTPt2Xm;SDISPTPt2Xp;SDISPTPt2Zp;...
%           SDISPTPtYmZm;SDISPTPtYmZp;SDISPTPtYpZm;SDISPTPtYpZp;SDISPTPt2YpZp;SDISPTPt2YmZp]; %;SDISPTPt2Ym;SDISPTPt2Yp;

SDISPT = [;SDISPTAXp;SDISPTAXm;SDISPTAYmL;SDISPTAYpL;...%
          SDISPTAYmR;SDISPTAYpR;...%
          SDISPTPbXm;SDISPTPbXp;...%SDISPTPbYm;SDISPTPbYp;
          SDISPTPtXm;SDISPTPtXp;...%SDISPTPtYm;SDISPTPtYp;
          SDISPTPbZ;...%SDISPTPt1Ym;SDISPTPt1Yp;          SDISPTPt1Xm;SDISPTPt1Xp;...
          SDISPTPt2Xm;SDISPTPt2Xp;SDISPTPt2Zp;...
          SDISPTPt2YpZp;SDISPTPt2YmZp]; %;SDISPTPt2Ym;SDISPTPt2Yp;
%       
     
 
      