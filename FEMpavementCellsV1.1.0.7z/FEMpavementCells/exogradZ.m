
function exoGrad = exogradZ(Zid,x,y,pl)
g = fittype('a-b*exp(-c*x)');
f0 = fit(x,y,g,'StartPoint',[0.1 -2 0.8]);
xx = linspace(1,Zid/2,Zid/2);
xx1 = linspace(Zid/2,Zid,Zid/2);
ExoGrad = f0(xx);
ExoGrad1 = flipud(ExoGrad);%f0(xx1);
exoGrad = [ExoGrad,ExoGrad1];
if pl
figure
plot(x,y,'o',xx,ExoGrad,'r-');
hold on
plot(xx1,ExoGrad1,'m-');
end
end
% plot(xx,exp())
