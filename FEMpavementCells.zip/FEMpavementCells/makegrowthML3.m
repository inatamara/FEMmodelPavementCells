function [yBC,xBC,zBC,yBC2,xBC2,zBC2,xBCAm,xBCAp,yBCA,grELALl,grELALr,grELARl,grELARr,grELAMl,grELAMr] ...
    = makegrowthML3(data,LE,CorNEW,index)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
global  Yidentity ELidentity Dmet1 Dmet2 Exo1 Exo2 Zidentity exoGrad  dispFg Nx NxT %IncompatibleXYZ
% global Nx %Ny NxT Nz npx npxt npy npz
% ELAL = [index.indPbLadjA,index.indAL,index.indPtLadjA,index.indPt2LadjA];
% ELAR = [index.indPbRadjA,index.indAR,index.indPtRadjA,index.indPt2RadjA];
% ELAM = [index.indPbJA,index.indAM,index.indPtJA,index.indPt2JA];
ELAL = index.indPbLadjA;
ELAR = index.indPbRadjA;
ELAM = index.indPbJA;
grELALl = 0;
grELALr = 0;
grELARl = 0;
grELARr = 0;
grELAMl = 0;
grELAMr = 0;
exoc1 = NaN;
exoc2 = NaN; 
for IE = 1:data.nel

    dimet1 = Dmet1(Yidentity(IE));
    dimet2 = Dmet2(Yidentity(IE));
    if Zidentity(IE)
    exoc1 = Exo1(Yidentity(IE))*exoGrad(Zidentity(IE));
    exoc2 = Exo2(Yidentity(IE))*exoGrad(Zidentity(IE));
    end
    disp = growthFML2(CorNEW(LE(IE,:),:),ELidentity(IE),dimet1,dimet2,exoc1,exoc2);
    dispFg(:,:,IE)=reshape(disp,3,8);
   if ismember(IE,ELAL)
       grELALl = grELALl+abs(dispFg(2,1,IE))+ abs(dispFg(2,4,IE));
       grELALr = grELALr+abs(dispFg(2,2,IE))+ abs(dispFg(2,3,IE));
   elseif ismember(IE,ELAR)
       grELARl = grELARl+abs(dispFg(2,1,IE))+ abs(dispFg(2,4,IE));
       grELARr = grELARr+abs(dispFg(2,2,IE))+ abs(dispFg(2,3,IE));
   elseif ismember(IE,ELAM)
       grELAMl = grELAMl+abs(dispFg(2,1,IE))+ abs(dispFg(2,4,IE));
       grELAMr = grELAMr+abs(dispFg(2,2,IE))+ abs(dispFg(2,3,IE));
   end
       
       
    
   if IE == data.nelPb + data.nelA + 2
        xBC = abs(dispFg(1,2,IE));
        yBC = abs(dispFg(2,2,IE));
        zBC = abs(dispFg(3,2,IE));
   elseif IE == data.nelPb + data.nelA + 1*data.nelPt+ 2
        xBC2 = abs(dispFg(1,2,IE));
        yBC2 = abs(dispFg(2,2,IE));
        zBC2 = abs(dispFg(3,2,IE));
   end
    if IE == data.nelPb + data.nelA + Nx/2 + NxT %ELidentity(IE) == 11
        xBCAm = abs(dispFg(1,1,IE)) + abs(dispFg(1,2,IE)) + ...
            abs(dispFg(1,3,IE)) + abs(dispFg(1,4,IE)) + ...
            abs(dispFg(1,5,IE)) + abs(dispFg(1,6,IE))+...
            abs(dispFg(1,7,IE)) + abs(dispFg(1,8,IE));
        xBCAm = xBCAm/4;  
    elseif IE == data.nelPb + data.nelA + Nx/2 + NxT + 1%ELidentity(IE) == 11
         xBCAm1 = abs(dispFg(1,1,IE)) + ...
            abs(dispFg(1,4,IE)) + ...
            abs(dispFg(1,5,IE)) +...
            abs(dispFg(1,8,IE));
         xBCAp1 = abs(dispFg(1,2,IE)) + ...
            abs(dispFg(1,3,IE)) + ...
            abs(dispFg(1,6,IE)) +...
            abs(dispFg(1,7,IE));
         yBCA = abs(dispFg(2,2,IE)) + ...
            abs(dispFg(2,3,IE)) + ...
            abs(dispFg(2,6,IE)) +...
            abs(dispFg(2,7,IE));
    elseif IE == data.nelPb + data.nelA + Nx/2 + 2 + NxT
        xBCAp = abs(dispFg(1,1,IE)) + abs(dispFg(1,2,IE)) + ...
            abs(dispFg(1,3,IE)) + abs(dispFg(1,4,IE)) + ...
            abs(dispFg(1,5,IE)) + abs(dispFg(1,6,IE))+...
            abs(dispFg(1,7,IE)) + abs(dispFg(1,8,IE));
        xBCAp = xBCAp/4;
    end

end
xBCAm = xBCAm + xBCAm1/2;
yBCA = yBCA/2;
xBCAp = xBCAp + xBCAp1/2;
end

