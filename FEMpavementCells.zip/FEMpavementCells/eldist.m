function L = eldist(ELXY,i,j)
%UNTITLED37 Summary of this function goes here
%   Detailed explanation goes here
L = sqrt((ELXY(i,1) - ELXY(j,1))^2 + (ELXY(i,2) - ELXY(j,2))^2 + (ELXY(i,3) - ELXY(j,3))^2);
end

