cols = unique(ELidentity);
cmap = jet(numel(cols));
ELidCmap = 0;
faces = face_connectivity(LE); 
ind =34;
tot = 1;
elwise = 0;
iter0 = 1:nel;%nelPb+1:nelA+nelPb+nelPt;%+nelA+1:nelPb+nelA+1*nelPt;
%IE= 1:nelPb+nelA+1%+2*nelPt:nelPb+nelA+3*nelPt%1:nel %number of elements 
normv = 0;
Cor = XYZT{ind}/20;%Cor;%{1};
fh = figure ;
axis equal ;
hold on
unitfac = 1;
col0 = [242 155 0]/255; %pmei
% col0 = 'none';
    patch('Vertices',Cor,'Faces',faces,...
    'FaceVertexCData',hsv(1),'FaceColor','none')



% figure;
% hold on
scatter3(Cor(constrainsPtYpZm,1),Cor(constrainsPtYpZm,2),Cor(constrainsPtYpZm,3),30,'.r')
scatter3(Cor(constrainsPtYpZp,1),Cor(constrainsPtYpZp,2),Cor(constrainsPtYpZp,3),30,'.b')

scatter3(Cor(constrainsPtYmZm,1),Cor(constrainsPtYmZm,2),Cor(constrainsPtYmZm,3),30,'.r')
scatter3(Cor(constrainsPtYmZp,1),Cor(constrainsPtYmZp,2),Cor(constrainsPtYmZp,3),30,'.b')

scatter3(Cor(constrainsPt2YmZp,1),Cor(constrainsPt2YmZp,2),Cor(constrainsPt2YmZp,3),30,'or')
scatter3(Cor(constrainsPt2YpZp,1),Cor(constrainsPt2YpZp,2),Cor(constrainsPt2YpZp,3),30,'ob')


corTot= zeros(8,3,data.nel); % compatible element displacements due to growth
for IE=1:data.nel% number of elements 
    corTot(:,:,IE) = XYZT{ind}(LE(IE,:),:)/(step*unit);
end
nelPtZant = nelPb+nelA+nelPt+Nx/2+1;%nelPb+nelA+Nx/2+2;
nelPtZsid = nelPb+nelA+nelPt+3;%nelPb+nelA+1;
% zBC1 = CompatibleXYZ(6,3,nelPtZant)/(step*unit) - CompatibleXYZ(6,3,nelPtZsid)/(step*unit);
zBC1 = abs(corTot(6,3,nelPtZant)/(step*unit) - corTot(6,3,nelPtZsid)/(step*unit));

scatter3(corTot(6,1,nelPtZant),corTot(6,2,nelPtZant),corTot(6,3,nelPtZant),60,'om')
scatter3(corTot(6,1,nelPtZsid),corTot(6,2,nelPtZsid),corTot(6,3,nelPtZsid),60,'oc')
%%
figure;
hold on
scatter3(Cor(constrainsAXm,1),Cor(constrainsAXm,2),Cor(constrainsAXm,3),30,'.r')
scatter3(Cor(constrainsAXp,1),Cor(constrainsAXp,2),Cor(constrainsAXp,3),30,'.b')
%
scatter3(Cor(constrainsPtXm,1),Cor(constrainsPtXm,2),Cor(constrainsPtXm,3),30,'*r')
scatter3(Cor(constrainsPtXp,1),Cor(constrainsPtXp,2),Cor(constrainsPtXp,3),30,'*b')
%%
figure;
hold on
scatter3(Cor(constrainsAYmL,1),Cor(constrainsAYmL,2),Cor(constrainsAYmL,3),30,'or')
scatter3(Cor(constrainsAYmR,1),Cor(constrainsAYmR,2),Cor(constrainsAYmR,3),30,'ob')

%%
figure;
hold on
scatter3(Cor(constrainsAYpL,1),Cor(constrainsAYpL,2),Cor(constrainsAYpL,3),30,'or')
scatter3(Cor(constrainsAYpR,1),Cor(constrainsAYpR,2),Cor(constrainsAYpR,3),30,'ob')
%%
figure;
hold on
% scatter3(Cor(constrainsPbXm,1),Cor(constrainsPbXm,2),Cor(constrainsPbXm,3),30,'^r')
% scatter3(Cor(constrainsPbXp,1),Cor(constrainsPbXp,2),Cor(constrainsPbXp,3),30,'^b')

scatter3(Cor(constrainsPtXm,1),Cor(constrainsPtXm,2),Cor(constrainsPtXm,3),30,'*r')
scatter3(Cor(constrainsPtXp,1),Cor(constrainsPtXp,2),Cor(constrainsPtXp,3),30,'*b')

% scatter3(Cor(constrainsPt1Xm,1),Cor(constrainsPt1Xm,2),Cor(constrainsPt1Xm,3),40,'*r')
% scatter3(Cor(constrainsPt1Xp,1),Cor(constrainsPt1Xp,2),Cor(constrainsPt1Xp,3),40,'*b')

scatter3(Cor(constrainsPt2Xm,1),Cor(constrainsPt2Xm,2),Cor(constrainsPt2Xm,3),50,'*r')
scatter3(Cor(constrainsPt2Xp,1),Cor(constrainsPt2Xp,2),Cor(constrainsPt2Xp,3),50,'*b')
%%
% figure;
% hold on
% scatter3(Cor(constrainsPbYm,1),Cor(constrainsPbYm,2),Cor(constrainsPbYm,3),30,'dr')
% scatter3(Cor(constrainsPbYp,1),Cor(constrainsPbYp,2),Cor(constrainsPbYp,3),30,'db')
% %%
% figure;
% hold on
% scatter3(Cor(constrainsPtYm,1),Cor(constrainsPtYm,2),Cor(constrainsPtYm,3),30,'sr')
% scatter3(Cor(constrainsPtYp,1),Cor(constrainsPtYp,2),Cor(constrainsPtYp,3),30,'sb')
% %%
% scatter3(Cor(constrainsPt1Ym,1),Cor(constrainsPt1Ym,2),Cor(constrainsPt1Ym,3),40,'sr')
% scatter3(Cor(constrainsPt1Yp,1),Cor(constrainsPt1Yp,2),Cor(constrainsPt1Yp,3),40,'sb')
% figure;
% hold on
% scatter3(Cor(constrainsPt2Ym,1),Cor(constrainsPt2Ym,2),Cor(constrainsPt2Ym,3),50,'sr')
% scatter3(Cor(constrainsPt2Yp,1),Cor(constrainsPt2Yp,2),Cor(constrainsPt2Yp,3),50,'sb')

%%
figure;
hold on
scatter3(Cor(constrainsPtZm,1),Cor(constrainsPtZm,2),Cor(constrainsPtZm,3),30,'pr')
scatter3(Cor(constrainsPtZp,1),Cor(constrainsPtZp,2),Cor(constrainsPtZp,3),30,'pb')
%%
figure;
hold on
% scatter3(Cor(constrainsPt2Zm,1),Cor(constrainsPt2Zm,2),Cor(constrainsPt2Zm,3),30,'pr')
scatter3(Cor(constrainsPt2Zp,1),Cor(constrainsPt2Zp,2),Cor(constrainsPt2Zp,3),30,'pb')
%%
leg = {'PbXm','PPbXp','PtXm','PtXp','AXm','AXp','AYm','AYp','PbYm','PbYp','PtYm','PtYp','PtZm','PtZp'};
legend(leg)