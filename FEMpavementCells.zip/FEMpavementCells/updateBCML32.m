%  This is the script for FEMpavementCells_1.m main function
%%
Xfac = 10;
nelAl = nelPb+1:3:nelPb+Ny*3;
yAl = abs(sum(squeeze(dispFg(2,1,nelAl))))+abs(sum(squeeze(dispFg(2,[1,4],nelAl(end)))));
nelAr = nelPb+3:3:nelPb+Ny*3;
yAr = abs(sum(squeeze(dispFg(2,2,nelAr))))+abs(sum(squeeze(dispFg(2,[2,3],nelAr(end)))));
%%
IEXmPt = data.nelPb+data.nelA+1:data.nelPb + data.nelA + NxT;
xbc1 = abs(sum(squeeze(dispFg(1,1,IEXmPt))))+abs(sum(squeeze(dispFg(1,2,IEXmPt(end)))));
% xbc1 = 2*xbc1;
SDISPTPbZ(:,3) = zeros(numel(constrainsPbZ)*1,1);
zBC = 4*zBC;
nelPtZant = nelPb+nelA+Nx/2+1;
nelPtZsid = nelPb+nelA+1;
SDISPTPtZm(:,3) = -zBC;%CompatibleXYZ(1,3,nelPtZant) - CompatibleXYZ(1,3,nelPtZsid);
SDISPTPtZp(:,3) = zBC;%CompatibleXYZ(5,3,nelPtZant) - CompatibleXYZ(5,3,nelPtZsid);
SDISPTPt2Zp(:,3) = 2*zBC;

% corTot= zeros(8,3,data.nel); % compatible element displacements due to growth
% for IE=1:data.nel% number of elements 
%     corTot(:,:,IE) = CorNEW(LE(IE,:),:);
% end
% nelPtZant = nelPb+nelA+Nx/2+1;
% nelPtZsid = nelPb+nelA+1;
% zBC1 = CompatibleXYZ(1,3,nelPtZant)/(step*unit) - CompatibleXYZ(1,3,nelPtZsid)/(step*unit);
% % zBC1 = abs(corTot(1,3,nelPtZant)/(step*unit) - corTot(1,3,nelPtZsid)/(step*unit));
% SDISPTPtYmZm(:,3) = -zBC1;
% SDISPTPtYmZp(:,3) = zBC1;
% SDISPTPtYpZm(:,3) = -zBC1;
% SDISPTPtYpZp(:,3) = zBC1;
% SDISPTPt2YpZp(:,3) = 2*zBC1;
% SDISPTPt2YmZp(:,3) = 2*zBC1;
SDISPTPtYmZm(:,3) = -zBC;
SDISPTPtYmZp(:,3) = zBC;
SDISPTPtYpZm(:,3) = -zBC;
SDISPTPtYpZp(:,3) = zBC;
SDISPTPt2YpZp(:,3) = 2*zBC;
SDISPTPt2YmZp(:,3) = 2*zBC;

nnindXextm = data.nCPb  + data.nCA +3 + npxt;
nnindXextp = data.nCPb  + data.nCA -2 + npxt;

SDISPTPtXm(:,3) = -xbc1/1.85;%-abs(disp(nnindXextp,1))-Xfac*xBC;
SDISPTPtXp(:,3) = xbc1/1.85;%abs(disp(nnindXextp,1))+Xfac*xBC;

% SDISPTPt2Xm(:,3) = -abs(disp(nnindXextp+2*nnode,1))-Xfac*xBC2;
% SDISPTPt2Xp(:,3) = abs(disp(nnindXextp+2*nnode,1))+Xfac*xBC2;

SDISPTPt2Xm(:,3) = -xbc1/1.85;%-abs(disp(nnindXextp,1))-Xfac*xBC;
SDISPTPt2Xp(:,3) = xbc1/1.85;%abs(disp(nnindXextp,1))+Xfac*xBC;

SDISPTPbXm(:,3) = -xbc1/1.85;%%-abs(disp(nnindXextp,1))-Xfac*xBC;
SDISPTPbXp(:,3) = xbc1/1.85;%abs(disp(nnindXextp,1))+Xfac*xBC;

nnindYextm = data.nCPb  + data.nCA +3 + npxt;

% SDISPTPtYm(:,3) = -abs(disp(nnindYextm,2))-yBC;
% SDISPTPtYp(:,3) = abs(disp(nnindYextm,2))+yBC;

% SDISPTPt2Ym(:,3) = -abs(disp(nnindYextm+2*nnode,2))-yBC2;
% SDISPTPt2Yp(:,3) = abs(disp(nnindYextm+2*nnode,2))+yBC2;
% 
% SDISPTPbYm(:,3) = -abs(disp(nnindYextm,2))-yBC;
% SDISPTPbYp(:,3) = abs(disp(nnindYextm,2))+yBC;
% 
% SDISPTAYm(:,3) =  -abs(disp(nnindYextm,2))-yBC;
% SDISPTAYp(:,3) = abs(disp(nnindYextm,2))+yBC;%yBCA
% AyFac = 10;
% grAy = min(grELALl,grELARr);
grAy = min(yAl,yAr)*max_lowD/min_highD;
SDISPTAYmL(:,3) = -grAy/2;
SDISPTAYpL(:,3) = grAy/2;%yBCA
SDISPTAYmR(:,3) = -grAy/2;
SDISPTAYpR(:,3) =  grAy/2;%yBCA

SDISPTAXm(:,3) =  -1.5*abs(xBCAm);
SDISPTAXp(:,3) = 1.5*abs(xBCAp); %;SDISPTAXm;SDISPTAXp

SDISPT = [;SDISPTAXp;SDISPTAXm;SDISPTAYmL;SDISPTAYpL;...%
          SDISPTAYmR;SDISPTAYpR;...%
          SDISPTPbXm;SDISPTPbXp;...%SDISPTPbYm;SDISPTPbYp;
          SDISPTPtXm;SDISPTPtXp;...%SDISPTPtYm;SDISPTPtYp;
          SDISPTPbZ;SDISPTPtZm;SDISPTPtZp;...%SDISPTPt1Ym;SDISPTPt1Yp;          SDISPTPt1Xm;SDISPTPt1Xp;...
          SDISPTPt2Xm;SDISPTPt2Xp;SDISPTPt2Zp;...
          SDISPTPtYmZm;SDISPTPtYmZp;SDISPTPtYpZm;SDISPTPtYpZp;SDISPTPt2YpZp;SDISPTPt2YmZp]; %;SDISPTPt2Ym;SDISPTPt2Yp;
      
BCs{ti} = SDISPT;
