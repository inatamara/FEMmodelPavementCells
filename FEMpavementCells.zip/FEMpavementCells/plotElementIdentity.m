
close all
cols = unique(ELidentity);
cmap = jet(numel(cols));
ELidCmap = 0;
faces = face_connectivity(LE); 
ind =1;
tot = 1;
elwise = 0;
iter0 = 1:nel;%nelPb+1:nelA+nelPb+nelPt;%+nelA+1:nelPb+nelA+1*nelPt;
%IE= 1:nelPb+nelA+1%+2*nelPt:nelPb+nelA+3*nelPt%1:nel %number of elements 
normv = 0;
cormat = XYZT{ind};%Cor;%{1};
fh = figure ;
axis equal ;
hold on
unitfac = 1;
% col0 = [217 192 255]/255; old pme
col0 = [39 0 54]/255; %pme
col0 = [0 56 64]/255; % wt
% col0 = [109 166 123]/255; old wt
col0 = [242 155 0]/255; %pmei
% col0 = 'none';
if tot
%     patch('Vertices',cormat,'Faces',faces,...
%     'FaceVertexCData',hsv(1),'FaceColor',col0,'FaceLighting',    'gouraud')
if elwise
        for IE = iter0
%         if ELidentity(IE) == 20 | ELidentity(IE) == -20 | ELidentity(IE) == -200
        set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
        patch('Vertices', cormat(LE(IE,:),:),'Faces',...
            [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',col0)      
        end
else
    patch('Vertices',cormat,'Faces',faces,...
    'FaceVertexCData',hsv(1),'FaceColor','none')
end
    alpha(0.3)
%     axis([-500 1200 -1200 2500])
%     view([60,37])
%     axis([-500 1200 -1000 2000])
    view([60,37])
%       view([-121,27])
%     axis([-3000 3000 -900 1300 -10 800])
%     axis([-2500 3000 -2100 2500 -10 1450])
    set(gca,'visible','off')
else

    for IE = iter0
%         if ELidentity(IE) == 20 | ELidentity(IE) == -20 | ELidentity(IE) == -200
        set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
        patch('Vertices', squeeze(XYZTcompatiblme{ind}(:,:,IE)),'Faces',...
            [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor',col0)     
            alpha(0.3)
%     axis([-500 1200 -1000 2000])
    view([60,37])
%     axis([-3000 3000 -900 1300 -10 800])
%     axis([-2500 3000 -2100 2500 -10 1450])
    set(gca,'visible','off')
    end
%         title('No Pressure')
    end
% end


hold on
for IE = iter0
    elIdentity = ELidentity(IE);
%   if (elIdentity == 1) | (elIdentity == 10) | (elIdentity == 11)...
%        | (elIdentity == -213)| (elIdentity == -415)| (elIdentity == -617)| (elIdentity == -819)...
%        | (elIdentity == sqrt(2)| (elIdentity == 110) | (elIdentity == 100))...
%        | (elIdentity == -2) | (elIdentity == -4)| (elIdentity == -6)| (elIdentity == -8)...
%         | (elIdentity == sqrt(3)| (elIdentity == 101) | (elIdentity == 111))...
%         | (elIdentity == -3) | (elIdentity == -5)| (elIdentity == -7)| (elIdentity == -9)
%     set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
% patch('Vertices', cormat(LE(IE,:),:),'Faces',...
%     [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','b')
%   end
% if (elIdentity == 2) | (elIdentity == -20) | (elIdentity == 20) | (elIdentity == 200)...% periclinal left
%       |(elIdentity == 2000)|(elIdentity == -200)...
%       |(elIdentity == 3) | (elIdentity == -30)| (elIdentity == 30) | (elIdentity == 300)...
%       |(elIdentity == 3000)|  (elIdentity == -300)...
%       |(elIdentity == 6) | (elIdentity == -60) | (elIdentity == 60) | (elIdentity == 600)...% periclinal left
%       |(elIdentity == 7) | (elIdentity == -70)| (elIdentity == 70) | (elIdentity == 700)...
%       |(elIdentity == -6)| (elIdentity == -7) |(elIdentity == -617)...
%       | (elIdentity == -700) |(elIdentity == -600)...
%       | (elIdentity == 6000) |(elIdentity == 6000)
% if (elIdentity == 7) | (elIdentity == -70) | (elIdentity == 70) | (elIdentity == 700)...% periclinal left
%       |(elIdentity == 7000)| (elIdentity == -700) | (elIdentity == -7000)...
%       |(elIdentity == 6) | (elIdentity == -60) | (elIdentity == 60) | (elIdentity == 600)...% periclinal left
%       |(elIdentity == 6000)| (elIdentity == -600)| (elIdentity == -6000)...
%       |(elIdentity == -6)| (elIdentity == -7) |(elIdentity == -617)
% if (elIdentity ==sqrt(2)) | (elIdentity == sqrt(3))
% if (elIdentity == 2) | (elIdentity == -20) | (elIdentity == 20) | (elIdentity == 200)...% periclinal left
%       |(elIdentity == 2000) | (elIdentity == -200)...
%       |(elIdentity == 3) | (elIdentity == -30)| (elIdentity == 30) | (elIdentity == 300)...
%       |(elIdentity == 3000)| (elIdentity == -300)
% if (elIdentity == -6)| (elIdentity == -7) | (elIdentity == -617) % top junction, third periclinal layer
%       set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
% patch('Vertices', cormat(LE(IE,:),:),'Faces',...
%     [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','b')
% end
% if (elIdentity == 1) | (elIdentity == 10) | (elIdentity == 11)...
%    | (elIdentity == -213)| (elIdentity == -415)| (elIdentity == -617)| (elIdentity == -819)
% 
% set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
% patch('Vertices', cormat(LE(IE,:),:),'Faces',...
%     [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','b')
% 
% elseif (elIdentity == sqrt(2)| (elIdentity == 110) | (elIdentity == 100))...
%      | (elIdentity == -2) | (elIdentity == -4)| (elIdentity == -6)| (elIdentity == -8)
%  
%  set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
% patch('Vertices', cormat(LE(IE,:),:),'Faces',...
%     [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','g')
% 
% elseif (elIdentity == sqrt(3)| (elIdentity == 101) | (elIdentity == 111))...
%         | (elIdentity == -3) | (elIdentity == -5)| (elIdentity == -7)| (elIdentity == -9)
%     
%     set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
% patch('Vertices', cormat(LE(IE,:),:),'Faces',...
%     [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','r')
% if (elIdentity == 200) | (elIdentity == 300) | (elIdentity == 2000)| (elIdentity == 3000)
% % elseif (elIdentity == 2) | (elIdentity == -20) | (elIdentity == 20) | (elIdentity == 200)...% periclinal left
% %      | (elIdentity == 4) | (elIdentity == -40)| (elIdentity == 40) | (elIdentity == 400)...
% %      | (elIdentity == 2000)| (elIdentity == 4000) | (elIdentity == -200)| (elIdentity == -400)
%  
%  set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
% patch('Vertices', cormat(LE(IE,:),:),'Faces',...
%     [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','y')
% end
if (elIdentity == 600) | (elIdentity == 700) | (elIdentity == 6000)| (elIdentity == 7000)
 
 set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
patch('Vertices', cormat(LE(IE,:),:),'Faces',...
    [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','c')
end
% elseif (elIdentity == 3) | (elIdentity == -30)| (elIdentity == 30) | (elIdentity == 300)...
%        | (elIdentity == 5) | (elIdentity == -50)| (elIdentity == 50) | (elIdentity == 500)...
%        | (elIdentity == 3000)| (elIdentity == 5000) | (elIdentity == -300)| (elIdentity == -500)
%    
%    set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
% patch('Vertices', cormat(LE(IE,:),:),'Faces',...
%     [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','m')
% 
% 
% elseif (elIdentity == 6) | (elIdentity == -60) | (elIdentity == 60) | (elIdentity == 600)...% periclinal left
%      | (elIdentity == 6000)| (elIdentity == -600)
%  
%  set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
% patch('Vertices', cormat(LE(IE,:),:),'Faces',...
%     [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','c')
% 
% elseif (elIdentity == 7) | (elIdentity == -70) | (elIdentity == 70) | (elIdentity == 700)...% periclinal left
%      | (elIdentity == 7000)| (elIdentity == -700)
%  
%  set(fh,'name','Preprocessing for FEA','numbertitle','off','color','w') ;
% patch('Vertices', cormat(LE(IE,:),:),'Faces',...
%     [1 2 3 4; 5 6 7 8;1 2 6 5;3 4 8 7;2 3 7 6;4 1 5 8],'FaceColor','w')
% end
end