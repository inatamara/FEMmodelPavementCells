Ny = 20;
x = 1:Ny+1;
xm = 11;
A1 = 1;
sig = 4;
y= A1*exp(-(((x-xm)/sig).^2)/2);%/sig/(2*pi);%/(2*(2*2));
yd = diff(y);
figure;
plot(x,y)
hold on

xd1 = x(1:Ny/2);
yd1 = yd(1:Ny/2);
plot(xd1,yd1,'r');

exofac = 1;
new_min = 0.02/exofac;%0.005; % straight wall exocytosis
new_max = 0.05/exofac;%0.13;%1.5; % neck exocytosis
ymax = nma_rescale(yd1,new_min,new_max);
new_min1 = 0.01/exofac;%0.005;
new_max1 = 0.035/exofac;%0.08;%1; % lobe exocytosis
ymin = nma_rescale(yd1,new_min1,new_max1);

plot(x(1:end-1),[ymax,fliplr(ymin)],'m');
