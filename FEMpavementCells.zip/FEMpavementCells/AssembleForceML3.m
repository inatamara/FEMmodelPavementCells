%% assembly of nodal forces
W =  [1,1]; 
GaussPoint = [-1/sqrt(3), 1/sqrt(3)]; % integration points, weights = 1
ff1 = zeros(24,1);
ff2 = zeros(24,1);
forceint = zeros(24,1);
fe = zeros(24,1);
%_____________________________LOCAL AXIS ELEMENT STIFFNESS MATRIX
pxn = CompatibleXYZ(:,1,IE)*10^(-9);
pyn = CompatibleXYZ(:,2,IE)*10^(-9);
pzn = CompatibleXYZ(:,3,IE)*10^(-9);
% pzn = repmat(mean(pzn),[8,1]);
elIdentity = ELidentity(IE);
if (elIdentity ==sqrt(2)) | (elIdentity == sqrt(3))
    
% for k=1:numel(GaussPoint)
     for j=1:numel(GaussPoint)
        for i=1:numel(GaussPoint)
%             g1=GaussPoint(k);%W(i);
            g2=GaussPoint(j);%W(j);
            g3=GaussPoint(i);%W(k);
            for g1 = [-1,1]                
                [shape,dshapedxi,dshapedeta,dshapedksi] = Shapefunctions3Dbrick(g1,g2,g3);      % compute shape functions and derivatives at sampling point
                [detjacobian,invjacobian,Jacobi]=Jacobian3D(nnel,dshapedxi,dshapedeta,dshapedksi,pxn,pyn,pzn);        % compute Jacobian

                jacobianSURF = cross(Jacobi(2,:)',Jacobi(3,:)');
                detjacobianSURF = norm(jacobianSURF);           
            if g1 == -1
            fe = Force3D(nnel,shape,forceel);          
            ff1 = ff1+fe*W(i)*W(j)*detjacobianSURF;
            else
            fe = Force3D(nnel,shape,forceel);          
            ff2 = ff2+fe*W(i)*W(j)*detjacobianSURF;
            end
            end
        end
     end
% end
elseif (elIdentity == 2) | (elIdentity == -20) | (elIdentity == 20) | (elIdentity == 200)...% periclinal left
      |(elIdentity == 2000)|(elIdentity == -200)...
      |(elIdentity == 3) | (elIdentity == -30)| (elIdentity == 30) | (elIdentity == 300)...
      |(elIdentity == 3000)|  (elIdentity == -300)...
      |(elIdentity == 6) | (elIdentity == -60) | (elIdentity == 60) | (elIdentity == 600)...% periclinal left
      |(elIdentity == 7) | (elIdentity == -70)| (elIdentity == 70) | (elIdentity == 700)...
      |(elIdentity == -6)| (elIdentity == -7) |(elIdentity == -617)...
      | (elIdentity == -700) |(elIdentity == -600)...
      | (elIdentity == 6000) |(elIdentity == 6000)
for k=1:numel(GaussPoint)
     for j=1:numel(GaussPoint)
%         for i=1:numel(GaussPoint)
            g1=GaussPoint(k);%W(i);
            g2=GaussPoint(j);%W(j);
%             g3=GaussPoint(i);%W(k);
            for g3 = [-1,1]                
                [shape,dshapedxi,dshapedeta,dshapedksi] = Shapefunctions3Dbrick(g1,g2,g3);      % compute shape functions and derivatives at sampling point
                [detjacobian,invjacobian,Jacobi]=Jacobian3D(nnel,dshapedxi,dshapedeta,dshapedksi,pxn,pyn,pzn);        % compute Jacobian

                jacobianSURF = cross(Jacobi(1,:)',Jacobi(2,:)');
                detjacobianSURF = norm(jacobianSURF);           
            if g1 == -1
            fe = Force3D(nnel,shape,forceel);          
            ff1 = ff1+fe*W(k)*W(j)*detjacobianSURF;
            else
            fe = Force3D(nnel,shape,forceel);          
            ff2 = ff2+fe*W(k)*W(j)*detjacobianSURF;
            end
            end
%         end
     end
end
end
forceint = ff1+ff2;