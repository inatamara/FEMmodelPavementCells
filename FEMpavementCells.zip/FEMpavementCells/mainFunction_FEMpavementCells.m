% this function is associated with article: 'Nanoscopy reveals pectin
% filaments and their role in plant epidermal morphogenesis' currently
% under review

% This is the main function, which solves nonlinear hyperelastic FEM
% problem applied to the growth and morphogenesis of Arabidopsis T.
% pavement cells. 
% Copyright (C) Kalina Tamara Haas, 2019, Paris, France
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 30/08/2019
%####################Begining of program
%% initialize variables, load data
cont =0; %  set to one  when running PME or PMEI condition
if ~cont
clc
clear 
close all 
cont =0;
else
    induction = 25; % index at which PME or PMEI induction starts
    CorNEW = XYZT{induction};
    CompatibleXYZ = XYZTcompatiblme{induction};
end

% input parameters for exocytosis rates and dymethylation
global WidthPectin PdemL PdemR PexoL PexoR PexpAV3D PexpZ PexpXY unit
unit =1;% in 1 nm: 10^(-9); % [nm]
step = 20; % mesh dimensions in nm
PME = 0;
PMEI = 0;
% pectin dimensions and pectin extension parameters 
PexpZ = abs(1.327-1.34)*unit; %0.08*unit;%[nm] compression of pectins in Z direction in nm
PexpXY = sqrt((0.99*1.23)/(0.837*0.837*sqrt(3)/2))*0.837-0.837*unit;%[nm] expansion of pectins in X, Y direction in nm
PexpAV3D = ((2*PexpXY-PexpZ)/3)*unit; %[nm] average pectin expansion in X, Y, Z
WidthPectin = 0.837*unit; % pectin width in [nm]
% sqrt((0.99*1.23)/(0.837*2*0.837*sqrt(3)/4)) ratio of the areas of two
% unit cells
% ratio of the short sides of the two squares: 0.99/0.7249 = 1.3657
% average lateral expansion (1.4695 + 1.3657)/2 =  1.4176
% ratio of the long sides of a squares: 1.23/0.837 = 1.4695
% periclinal wall exocytosis and dymethylation parameters
if ~PME&~PMEI&~cont % WT
    PdemL = 0.60; % pectin demethylation rate in left cell
    PdemR = 0.60; % pectin demethylation rate in right cell
    PexoL = 0.05; % pectin exocytosis rate in left cell
    PexoR = 0.05; % pectin exocytosis rate in right cell
elseif ~PME&PMEI&cont % PMEI
    PdemL = 0.05; % pectin demethylation rate in left cell
    PdemR = 0.05; % pectin demethylation rate in right cell
    PexoL = 0.05; % pectin exocytosis rate in left cell
    PexoR = 0.05; % pectin exocytosis rate in right cell
elseif PME&~PMEI&cont
    PdemL = 0.9; % pectin demethylation rate in left cell
    PdemR = 0.9; % pectin demethylation rate in right cell
    PexoL = 0.017; % pectin exocytosis rate in left cell
    PexoR = 0.017; % pectin exocytosis rate in right cell
end
exofac = 1; % scale the exocytosis
% input parameters from the super res data
if ~PME&~PMEI&~cont % WT
    min_highD = 0.61; % straight wall demethylation
    max_highD = 0.57; % max neck wall demethylation
    max_lowD = 0.41; % max lobe wall demethylation
    min_highE = 0.05/exofac;%0.005; % straight wall exocytosis
    max_highE = 0.05/exofac;%0.13;%1.5; % neck exocytosis
    max_lowE = 0.05/exofac;%0.08;%1; % lobe exocytosis 
elseif ~PME&PMEI&cont % PME
    min_highD = 0.05; % straight wall demethylation
    max_highD = 0.05; % max neck wall demethylation
    max_lowD = 0.05; % max lobe wall demethylation
    min_highE = 0.05/exofac;%0.005; % straight wall exocytosis
    max_highE = 0.05/exofac;%0.13;%1.5; % neck exocytosis
    max_lowE = 0.05/exofac;%0.08;%1; % lobe exocytosis 
elseif PME&~PMEI&cont
    min_highD = 0.9; % straight wall demethylation
    max_highD = 0.9; % max neck wall demethylation
    max_lowD = 0.9; % max lobe wall demethylation
    min_highE = 0.017/exofac;%0.005; % straight wall exocytosis
    max_highE = 0.017/exofac;%0.13;%1.5; % neck exocytosis
    max_lowE = 0.017/exofac;%0.08;%1; % lobe exocytosis 
end
%%
global Nx Ny NxT Nz npx npxt npy npz Pt2Gr Pt1GrZtop Pt1Gr
relobe = 0; % to create secondary lobes
Pt2Gr = 0; % set one to grow third pericilinal nodal layer
Pt1Gr = 0; % put one to grow second pericilinal nodal layer
Pt1GrZtop = 1; %controls exocytosis of the top nodes of first periclinal layer
nnel = 8; % number of nodes per element
par = 0;
% turgor pressure
PxL = 250000/4; % per node, pressure applied to a face with 4 nodes
PxR = 250000/4;
PzL = PxL;
PzR = PxR;
PzLb = PzL;
PzRb = PzR;
Patm = 100000/4; % atmospheric pressure
%% #######################  MESH DATA
% 8 node hexaedral element with 24 dofs; 3 dofs per node: x, y, z
% node 1: dof 1, 2, 3, node 2: dof 4, 5, 6 ...node 8: dof 22, 23 24
% load mesh. Mesh of a H shape using 8 noded brick Elements   
load('MeshData.mat') % loading matlab data containing mesh
% this mesh models two cell junctions as H shape using periclinal bottom
% wall with one layer, periclinal top wall with two layers and anticlinal
% wall with 3 layers of elements.
% the following varibles are loaded:

% LE nodal connectivity matrix, connectivity of the elements
%           -----> nodes(i,:) = [node1 node2...node8] for ith mesh element
% Cor - The nodal coordinates of the mesh
%           -----> coordinates = [X Y Z] (no units applied)
% faces - faces of each hexaedral element
% nodesPb - nodal connectivity matrix for periclinal bottom wall
% nodesA - nodal connectivity matrix for anticlinal walls
% nodesPt - nodal connectivity matrix for first periclional top wall layer
% nodesPt2 - nodal connectivity matrix for second periclional top wall layer

%Solid element constant dimensions
% L   isze in X direction
% B  Size in Y direction
% H  height in Z
% sheet thickness along different dimensions
% orW  sheet thicknes
% orWz = 1; sheet thickness along z
% orWx =1; sheet thickness along x
% Nx  number of elemntnts in X direction
% Ny  number of elemntnts in Y direction
% Nz number of elemntnts in Z direction
% NxT  total number of elements in x direction for periclinal wall; 
% % +1 corresponds to junction with anticlinal (central element)
% npx = Nx + 1;
% npxt = NxT+1;
% npy = Ny + 1;
% npz = Nz + 1;
% NzPer = 1; % number of elements along sheet thickness
%% assigning some variables from mesh data
nnode = data.nnodePb/2; % nimber of nodes per one periclinal wall sheet
nelPb = data.nelPb; % number of elements in periclinal bottom wall
nelPt = data.nelPt; % number of elements in periclinal top 1st wall
nelA = data.nelA; % number of elements in anticlonal wall
nel=size(LE,1);   % Elements Number
%%   get element identity matrix
[ELidentityPb,ELidentityA,ELidentityPt,ELidentityPt2,indJ,index] = ...
ElementIdentityMatrix(data,Nx,NxT,Ny,Nz);
%% ssembling total element identity matrix, e.g.: 1 - periclinal wall away from border
global ELidentity
ELidentity = [ELidentityPb;ELidentityA;ELidentityPt;ELidentityPt2];
%% BC: writting initial boundary conditions BCs
setBCinitialML32 % running script setting up BCs
%% ##################INPUT DATA###############   
% getting element y value position to set sinusoidal lobines for anticlinal
% wall in Y direction
YindP = zeros(Ny,NxT);
for ii = 1:Ny
YindP(ii,:) = ii*ones(1,NxT);
end
YindP = sort(YindP(:));
YA = repmat([1:Ny],[3,Nz]);
YA1 = YA(:);
global Yidentity
Yidentity = [YindP;YA1;YindP;YindP;YindP];
%% z direction exocytosis gradient (if applicable)
global Zidentity exoGrad
ZidentityPb = zeros(Ny*NxT,1);
ZidentityPb([indJ;index.indL;index.indR]) = 1;
ZidentityPt = zeros(Ny*NxT,1);
ZidentityPt([indJ;index.indL;index.indR]) = 2+Nz;
ZidentityPt2 = zeros(Ny*NxT,1);
ZidentityPt2([indJ;index.indL;index.indR]) = 3+Nz;
ZidentityA = zeros(nelA,1);
flag = [1:3*Ny:nelA,nelA];
for iiz = 1:Nz
    ZidentityA([flag(iiz):flag(iiz+1)-1],:) = iiz+1;  
end
ZidentityA(end) = ZidentityA(end-1);
% ZidentityA = repmat([2:Nz+1]',[1,Ny]);
Zidentity = [ZidentityPb;sort(ZidentityA(:));ZidentityPt;ZidentityPt2];
Zid = Nz+3;
% parabolic profile
x = [1,Zid/2+0.5,Zid]; y = [1 0.1 1]; p = polyfit(x,y,2);
exoGrad = polyval(p,1:Zid);
exoGrad = ones(size(exoGrad));
exoGrad([1,Nz+2:Nz+3]) = 1; % no exocytosis gradient in Z direction
% %exponential profile
% x = [1,2,4,Zid/2+0.5]'; y = [1 0.5 0.2 0.1]';
% exoGrad = exogradZ(Zid,x,y,0);
% exoGrad = exoGrad(:);
%% % anticlinal wall parameters for demethylation profiles in y direction
global Dmet1 Dmet2
gauss = [];
prof1 = EXOprofile(min_highD,max_highD,max_lowD,Ny,gauss);
Dmet1 = prof1;
Dmet2 = flipud(Dmet1);
%% lobines for exocytosis
gauss = [];
global Exo1 Exo2
prof = EXOprofile(min_highE,max_highE,max_lowE,Ny,gauss);
Exo1 = prof;
Exo2 = flipud(Exo1);
%% Set program parameters; setting Newton-Rapson and Bisection  parameters
% External forces [Node, DOF, Value] and Prescribed displacements [Node, DOF, Value]
% Load increments [Start End Increment InitialFactor FinalFactor]
TIMS=[0.0 1 1 0.0 1]';%[0.0 0.5 0.5 0.0 0.5; 0.5 1.0 0.5 0.5 1.0]';
TIMSG=[0.0 1 1 0.0 1]';
LEC=[];
ITRA=30; ATOL=1.0E5; NTOL=12; TOL=1E-4;

XYZ=step*unit*Cor; % step, multiplication factor in nm to adjust dimensions of mesh 
if ~cont
CorNEW = XYZ; % initialize nodes coordinates matrix
CompatibleXYZ = zeros(8,3,data.nel); % compatibel grown position an time ti
end
EXTFORCEtot1 = [];
for IE=1:data.nel% number of elements
    if ~cont
    CompatibleXYZ(:,:,IE) = XYZ(LE(IE,:),:); % compatibel grown position an time ti
    end
    force = updateForceML3(CompatibleXYZ(:,:,IE),LE(IE,:),ELidentity(IE),PzR,PzL,Patm);
    forceel = force(:,3);
    AssembleForceML3
    EXTFORCEtot1 = [EXTFORCEtot1;force(:,1:2),forceint(:),force(:,4)];
end
EXTFORCE1 = EXTFORCEtot1(find(EXTFORCEtot1(:,3)~=0),1:3);
%% ####################### NOTIFICATION
% The follopwing code is substantialy inspired by the codes from the book:
% Introduction to Nonlinear Finite Element Analysis by Nam-Ho Kim
% It was modified to account for the growth. However the
% method to solve nonlinear FEM problems with hyperelastic materials was kept the same
% as in the book. To better understand solveing procedure with Newto-Rapson
% method, please refer to book's chapter 3.
% ####################### MATERIALS PROPERTIES
% first solving issue with units; here we are at the scale of nm, 
% nm^2 = 10^-18 m^2 =
% parameters for mooney rivlin model or neo-hookean model
unitfactor = 10^(-18); % convert to N/nm^2
% Material properties 
A10 = 10000000*unitfactor;
A01 = 1000000*unitfactor; % set to 0 for neo-hookean model
MID = -1; %hyperelastic
PROP = [A10 A01 100000000*unitfactor 1000000*unitfactor];
%% initialize cell arrays for storing results at each ti iteration
time = 200; % number of iterations
XYZT= cell(numel(time),1);
dispFgINC= cell(numel(time),1); % store displacements due to incompatible growth
XYZTcompatiblme  = cell(numel(time),1); % store compatible grown position
global dispFg
dispFg = [];
disp = zeros(size(CorNEW));
%%
for ti = 1:time
ti
NOUT =[];
[yBC,xBC,zBC,yBC2,xBC2,zBC2,xBCAm,xBCAp,yBCA,grELALl,grELALr,grELARl,grELARr,grELAMl,grELAMr] ...
    = makegrowthML3(data,LE,CorNEW,index);
updateBCML32 % script to update boundary condition for next iteration

% Calling main FEM function only growth, no pressure
% following function is a modification of NLFE function from Nam-Ho Kim's
% book. The main modification includes growth incorporation
% LE nodal connectivity matrix, CompatibleXYZ compatible grown position
% ITRA,TOL,ATOL,NTOL,TIMSG,NOUT,MID,PROP: material parameters and
% minimization parameters
%outG includes growth only
outG = NLFEAgrowth(ITRA,TOL,ATOL,NTOL,TIMSG,NOUT,MID,PROP,[],BCs{ti},LE,size(CorNEW),CompatibleXYZ,1);
dispGFecomp = zeros(size(CorNEW)); % extract dispalcements due to compatible growth
for I=1:numel(outG.DISPTD)/3
II=outG.NDOF*(I-1);
dispGFecomp(I,:) = outG.DISPTD(II+1:II+3);
end
% adjust the dimension of compatible displacements matrix to match
% CompatibleXYZ (nnode x 3 x nel), nnode: total number of nodes, nel: total
% number of elements
dispCompatible= zeros(8,3,data.nel); % compatible element displacements due to growth
for IE=1:data.nel% number of elements  
    dispCompatible(:,:,IE) = dispGFecomp(LE(IE,:),:); 
end
%  growth and applied pressure
out = NLFEAgrowth(ITRA,TOL,ATOL,NTOL,TIMS,NOUT,MID,PROP,EXTFORCE1,BCs{ti},LE,size(CorNEW),CompatibleXYZ,1);
% update nodal coordinatres matrix for next iteration
CompatibleXYZ = CompatibleXYZ + dispCompatible;
XYZTcompatiblme{ti} = CompatibleXYZ; % store incompatible coordinates

dispFgINC{ti} = dispFg;% out.dispGrowth; % store displacements due to growth
clear growth
% fclose(NOUT);
disp = zeros(size(CorNEW));
for I=1:numel(out.DISPTD)/3
II=out.NDOF*(I-1);
disp(I,:) = out.DISPTD(II+1:II+3);
end
% update nodal coordinatres matrix for next iteration, growth and pressure
CorNEW = CorNEW + disp;
XYZT{ti} = CorNEW;
% update forces for next iteration, by calculating normal to the element fa
% face to find force x, y, z coordinates (update force)
% then forces are integrated over appriopriate faces (AssembleForceML3)
EXTFORCEtot1 = [];
for IE=1:data.nel% number of elements
    force = updateForceML3(CompatibleXYZ(:,:,IE),LE(IE,:),ELidentity(IE),PxL,PxR,Patm);
    forceel = force(:,3);
    AssembleForceML3 % script for force gauss integration
    EXTFORCEtot1 = [EXTFORCEtot1;force(:,1:2),forceint(:),force(:,4)];
end
%
EXTFORCE1 = EXTFORCEtot1(find(EXTFORCEtot1(:,3)~=0),1:3);
% save(strcat(savefolder,num2str(ti),'.mat'),'stressG','stress') % saving
% selected data at each iteration, takes lots of space
% clear stressG stress 
end