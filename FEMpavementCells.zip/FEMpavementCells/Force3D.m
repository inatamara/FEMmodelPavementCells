function F = Force3D(nnel,shape,P)

%--------------------------------------------------------------------------
% Purpose :
%         Determines the force vector for the element 'iel'
% Synopsis :
%          [F] = Force(nnel,shape,P) 
% Variable Description:
%           F - element force vector
%           nnel - number of nodes per element
%           shape - Shape functions for the element
%           P - applied pressure
%--------------------------------------------------------------------------

for i = 1:nnel
    i1=(i-1)*3+1;  
    i2=i1+1;
    i3=i2+1;
    F(i1,1) = P(i1)*shape(i);
    F(i2,1) = P(i2)*shape(i);
    F(i3,1) = P(i3)*shape(i);
end
