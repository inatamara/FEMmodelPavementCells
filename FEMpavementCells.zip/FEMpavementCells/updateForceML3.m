function [force,Area1,Area2,normal1,normal2,center1,center2,face1,face2] = updateForceML3(elicoord,nodeeli,elIdentity,P1,P2,Patm)

%  This is the subfunction of FEMpavementCells_1.m main function
% updateForce: calculates normal to the element face in order to find surface load in x,
% y and z directions
%  elicoord: coordinate of an element
% nodeeli: global node numbers of an element
% elIdentity: element identity (e.g. anticlinal, periclinal left top,
% junction of anticlinal and periclinal bottom, etc)
% P1, P2: turgor pressure in left and right cells with respect to anticlinal wall
% Patm: atmospheric pressure

if     elIdentity == sqrt(2) % left anticlinal layer 
        face1 = elicoord([1,4,5,8],:);
        face2 = [];
elseif elIdentity == sqrt(3) %right anticlinal layer  
        face1 = [];
        face2 = elicoord([2,3,6,7],:);
    % third, last periclinal layer xy faces, atmospheric pressure applied
    % to top face
elseif (elIdentity == 7) | (elIdentity == -70) | (elIdentity == 70) | (elIdentity == 700)...% periclinal left
      |(elIdentity == 7000)| (elIdentity == -700) | (elIdentity == -7000)...
      |(elIdentity == 6) | (elIdentity == -60) | (elIdentity == 60) | (elIdentity == 600)...% periclinal left
      |(elIdentity == 6000)| (elIdentity == -600)| (elIdentity == -6000)...
      |(elIdentity == -6)| (elIdentity == -7) |(elIdentity == -617)
      
        face1 = [];
        face2 = elicoord([5,6,7,8],:);
    % first periclinal left and right
elseif (elIdentity == 2) | (elIdentity == -20) | (elIdentity == 20) | (elIdentity == 200)...% periclinal left
      |(elIdentity == 2000) | (elIdentity == -200)...
      |(elIdentity == 3) | (elIdentity == -30)| (elIdentity == 30) | (elIdentity == 300)...
      |(elIdentity == 3000)| (elIdentity == -300)
  
      face1 = elicoord([1,2,3,4],:);
      face2 = [];%elicoord([5,6,7,8],:);
elseif (elIdentity == -6)| (elIdentity == -7) | (elIdentity == -617) % top junction, third periclinal layer
    face1 = [];
    face2 = elicoord([5,6,7,8],:);
else
    face2 = [];
    face1 = [];
end

if ~isempty(face1)
    P1L = face1(1,:); 
    P2L = face1(2,:); 
    P3L = face1(3,:); 
    P4L = face1(4,:);
    center1 = P1L+P2L+P3L+P4L;
    center1 = center1/4;
    normal1 = cross(P1L-P2L, P1L-P3L); % calculate normal to the face using 3 face's nodes
    normal1 = normal1 / norm( normal1 ); % just to make it unit length
    if elIdentity == sqrt(2) % anticlinal left
        if normal1(1) < 0
            normal1 = -normal1;
        end
    else
        if normal1(3) < 0
            normal1 = -normal1;
        end
    end
    AreaP1P2P4L = 1/2*norm(cross(P2L-P1L,P4L-P1L));
    AreaP2P3P4L = 1/2*norm(cross(P3L-P2L,P4L-P2L));
    Area1 = abs(AreaP1P2P4L + AreaP2P3P4L);
%     Area1 = 1;
else
Area1 =  0;
normal1 = 0*ones(3,1);
center1 = [NaN,NaN,NaN]';
end

if ~isempty(face2)
    P1R = face2(1,:); 
    P2R = face2(2,:); 
    P3R = face2(3,:); 
    P4R = face2(4,:);
    center2 = P1R+P2R+P3R+P4R;
    center2 = center2/4;
    normal2 = cross(P1R-P2R, P1R-P3R);
    normal2 = normal2 / norm( normal2 ); % just to make it unit length
    if elIdentity == sqrt(3) % anticlinal right
        if normal2(1) >0
            normal2 = -normal2;
        end
    else
        if normal2(3) > 0
            normal2 = -normal2;
        end
    end
        % calculate area of the two anticloinal wall faces
        AreaP1P2P4R = 1/2*norm(cross(P2R-P1R,P4R-P1R));
        AreaP2P3P4R= 1/2*norm(cross(P3R-P2R,P4R-P2R));
        Area2 = abs(AreaP1P2P4R + AreaP2P3P4R);
%         Area2 = 1;

else
Area2 =  0;
normal2 = 0*ones(3,1);
center2 = [NaN,NaN,NaN]';
end

% nodeeli
force = zeros(24,3);
nodes(1:3:24,1) = nodeeli;
nodes(2:3:24,1) = nodeeli;
nodes(3:3:24,1) = nodeeli;
force(:,2) = repmat([1;2;3],[8,1]);
force(:,1) = nodes;
tmp = zeros(24,1);
force(:,3) = tmp;
force(:,4) = elIdentity*ones(24,1);
if elIdentity == sqrt(2) % anticlinal left
    tmp([1,10,13,22],1) = P1*normal1(1); % left yz P1ane x coordinate
    tmp([2,11,14,23],1)= P1*normal1(2); % left yz P1ane y coordinate
    tmp([3,12,15,24],1)= P1*normal1(3); % left yz P1ane z coordinate
elseif elIdentity == sqrt(3) % anticlinal right
    tmp([4,7,16,19],1) = P2*normal2(1); % righ yz P1ane x coordinate
    tmp([5,8,17,20],1)= P2*normal2(2); % right yz P1ane y coordinate
    tmp([6,9,18,21],1)= P2*normal2(3); % right yz P1ane z coordinate
    
elseif (elIdentity == 2) | (elIdentity == 20)  | (elIdentity == -20)... % 1st peric top left
       | (elIdentity == 200) | (elIdentity == 2000)  | (elIdentity == -200) | (elIdentity == -2000)% peric top left
    tmp([1,4,7,10],1) = P1*normal1(1); % bottom xy P1ane x coordinate
    tmp([2,5,8,11],1)= P1*normal1(2); % bottom xy P1ane y coordinate
    tmp([3,6,9,12],1)= P1*normal1(3); % bottom xy P1ane z coordinate
   
elseif (elIdentity == 6) | (elIdentity == 60)  | (elIdentity == -60)... % third peric top left
       | (elIdentity == 600) | (elIdentity == 6000)  | (elIdentity == -600) | (elIdentity == -6000)% peric top left
    tmp([13,16,19,22],1) = Patm*normal2(1); % top xy P1ane x coordinate
    tmp([14,17,20,23],1)= Patm*normal2(2); % top xy P1ane y coordinate
    tmp([15,18,21,24],1)= Patm*normal2(3); % top xy P1ane z coordinate

elseif (elIdentity == 3) | (elIdentity == 30)  | (elIdentity == -30)...% 1st peric top right
        | (elIdentity == 300) | (elIdentity == 3000)  | (elIdentity == -300) | (elIdentity == -3000)
    tmp([1,4,7,10],1) = P2*normal1(1); % bottom xy P1ane x coordinate
    tmp([2,5,8,11],1)= P2*normal1(2); % bottom xy P1ane y coordinate
    tmp([3,6,9,12],1)= P2*normal1(3); % bottom xy P1ane z coordinate
elseif (elIdentity == 7) | (elIdentity == 70)  | (elIdentity == -70)...% 3rd peric top right
        | (elIdentity == 700) | (elIdentity == 7000)  | (elIdentity == -700)  | (elIdentity == -7000)
    % P atm atmosperic P2essure
    tmp([13,16,19,22],1) = Patm*normal2(1); % top xy P1ane x coordinate
    tmp([14,17,20,23],1)= Patm*normal2(2); % top xy P1ane y coordinate
    tmp([15,18,21,24],1)= Patm*normal2(3); % top xy P1ane z coordinate
    
elseif (elIdentity == -6)| (elIdentity == -7) | (elIdentity == -617)  % 3rd peric top junction elements
    % P atm atmosperic P2essure
    tmp([13,16,19,22],1) = Patm*normal2(1); % top xy P1ane x coordinate
    tmp([14,17,20,23],1)= Patm*normal2(2); % top xy P1ane y coordinate
    tmp([15,18,21,24],1)= Patm*normal2(3); % top xy P1ane z coordinate
end
force(:,3) = tmp;
end